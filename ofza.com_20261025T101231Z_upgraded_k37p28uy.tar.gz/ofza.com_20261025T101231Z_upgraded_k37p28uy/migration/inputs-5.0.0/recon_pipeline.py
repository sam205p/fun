#!/usr/bin/env python3
"""Recon Pipeline 5: bounded asset inventory, not a vulnerability scanner."""
import argparse
import collections
import concurrent.futures
import contextlib
import datetime
import errno
import hashlib
import html.parser
import http.client
import io
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import select
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import uuid
import xml.etree.ElementTree as ET

from recon_runtime import StateStore, read_saved, AdaptivePacer
from recon_discovery import Discovery, AuthProfiles, comparison_quality, origin
from recon_browser import browser_round

VERSION = "5.0.0"
SCHEMA = "recon-pipeline/3"
DNS_TYPES = ("A", "AAAA", "CNAME")
STOP = threading.Event()


class Interrupted(Exception):
    pass


class BudgetExceeded(Exception):
    pass


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_json(path, data):
    temp = path.with_suffix(path.suffix + ".part")
    with temp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def lines(path):
    with Path(path).open(encoding="utf-8-sig") as f:
        for number, row in enumerate(f, 1):
            row = row.strip()
            if row and not row.startswith("#"):
                yield number, row


def host(value):
    value = value.lower().rstrip(".")
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        pass
    if len(value) > 253 or not value.isascii() or "." not in value:
        raise ValueError("Expected an ASCII/Punycode FQDN or IP: " + value)
    if not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", p)
               for p in value.split(".")):
        raise ValueError("Invalid hostname: " + value)
    # Numeric forms must not bypass the IP policy via OS-specific resolution.
    if all(p.isdigit() for p in value.split(".")):
        raise ValueError("Invalid IP literal: " + value)
    return value


def is_ip(value):
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def rule(value):
    if value.startswith("*."):
        base = host(value[2:])
        if is_ip(base):
            raise ValueError("Wildcard IP rules are invalid")
        return "*." + base
    return host(value)


def matches(name, pattern):
    return name.endswith(pattern[1:]) if pattern.startswith("*.") else name == pattern


def url_normalize(value, base=None):
    if base:
        value = urllib.parse.urljoin(base, value)
    if any(ord(c) <= 32 or ord(c) == 127 for c in value) or "\\" in value:
        raise ValueError("URL contains whitespace, controls or backslash")
    u = urllib.parse.urlsplit(value)
    if u.scheme not in ("http", "https") or not u.hostname or u.username is not None or u.password is not None:
        raise ValueError("Expected an HTTP(S) URL without credentials")
    name = host(u.hostname)
    port = u.port or (443 if u.scheme == "https" else 80)
    if not 1 <= port <= 65535:
        raise ValueError("Invalid URL port")
    authority = "[" + name + "]" if ":" in name else name
    if port != (443 if u.scheme == "https" else 80):
        authority += ":" + str(port)
    # Encode non-ASCII paths without changing already escaped bytes.
    path = urllib.parse.quote(u.path or "/", safe="/%:@!$&'()*+,;=-._~")
    query = urllib.parse.quote(u.query, safe="/%?:@!$&'()*+,;=-._~[]")
    return urllib.parse.urlunsplit((u.scheme, authority, path, query, ""))


def ports(value):
    result = set()
    for part in value.split(","):
        if not re.fullmatch(r"[0-9]+(?:-[0-9]+)?", part):
            raise argparse.ArgumentTypeError("Use comma-separated ports/ranges, e.g. 80,443,8000-8010")
        bounds = [int(p) for p in part.split("-")]
        start, end = bounds[0], bounds[-1]
        if not 1 <= start <= end <= 65535:
            raise argparse.ArgumentTypeError("Ports must be in 1..65535, with ascending ranges")
        result.update(range(start, end + 1))
    return sorted(result)


def positive(value):
    n = int(value)
    if n < 1:
        raise argparse.ArgumentTypeError("Must be a positive integer")
    return n


def port_expression(values):
    """Keep full-range Nmap invocations below OS argument length limits."""
    groups = []
    start = previous = values[0]
    for number in values[1:]:
        if number != previous + 1:
            groups.append(str(start) if start == previous else "%d-%d" % (start, previous))
            start = number
        previous = number
    groups.append(str(start) if start == previous else "%d-%d" % (start, previous))
    return ",".join(groups)


def nonnegative(value):
    n = int(value)
    if n < 0:
        raise argparse.ArgumentTypeError("Must be zero or greater")
    return n


def nonnegative_float(value):
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise argparse.ArgumentTypeError("Must be finite and zero or greater")
    return number


def parser():
    p = argparse.ArgumentParser(
        description="Recon Pipeline 5 -- authorized DNS, IP, TCP/service and web asset inventory.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        epilog="Example: bash recon_pipeline.sh example.com --authorized --active --port-scan "
               "--wordlist words.txt --crawl --httpx-enrich\n"
               "Exit codes: 0 completed, 1 partial/failed stage, 2 input/preflight error, "
               "124 run timeout, 130 interrupted, 143 terminated. No exploitation or form submission.")
    p.add_argument("domain", nargs="?", help="Root domain; optional for IP-only --targets")
    p.add_argument("--version", action="version", version=VERSION)
    for name, helptext in [
        ("authorized", "Confirm authorization for selected names, addresses and actions"),
        ("active", "Enable DNS and HTTP network probes; default is passive collection"),
        ("check", "Validate inputs and tool interfaces only; no target probes"),
        ("skip-passive", "Do not call subfinder"),
        ("no-bruteforce", "Disable DNS wordlist generation even when --wordlist is supplied"),
        ("allow-private", "Permit private/loopback/special unicast destination IPs"),
        ("port-scan", "Scan resolved and explicitly supplied IPs using Nmap TCP connect"),
        ("service-detection", "Enable Nmap -sV --version-light; sends additional service probes"),
        ("reverse-dns", "Query PTR records for discovered and explicit allowed IPs"),
        ("probe-all-open", "Try HTTP and HTTPS on every discovered open TCP port"),
        ("crawl", "Bounded GET-only HTML/JS/robots/sitemap discovery; no browser execution"),
        ("archive", "Collect historical URLs using gau; historical does not imply live"),
        ("probe-archives", "Allow historical URLs to enter the bounded HTTP queue"),
        ("httpx-enrich", "Enrich verified live URLs with ProjectDiscovery httpx technology detection"),
        ("tls-verify", "Require trusted, hostname-valid TLS certificates (default inventory accepts invalid certs)"),
        ("subfinder-all", "Ask subfinder to query all available sources (may require API keys)"),
    ]:
        p.add_argument("--" + name, action="store_true", help=helptext)
    for name, helptext in [
        ("targets", "File of explicit hostname, HTTP(S) URL, IP or CIDR seeds; repeatable"),
        ("passive-file", "Import hostnames/URLs or subfinder JSONL instead of running subfinder"),
        ("url-file", "Import historical URL leads; active probing requires --probe-archives"),
        ("wordlist", "DNS prefix wordlist; repeatable, no hidden/default wordlist"),
    ]:
        p.add_argument("--" + name, action="append", default=[], metavar="FILE", help=helptext)
    for name, helptext in [
        ("scope", "Optional exact/wildcard domain rules; exact names become seeds"),
        ("exclude", "Excluded exact/wildcard names or IP/CIDRs; exclusions win"),
        ("ip-allow", "Optional destination IP/CIDR restriction; does not create targets"),
        ("resolvers", "Recursive DNS servers: IP or IP#PORT, one per line; default OS resolver"),
        ("trusted-resolvers", "Independent DNS retry servers; used for negative/error results"),
        ("baseline", "Previous report.json for observation deltas, not proof of asset removal"),
        ("provider-config", "Subfinder provider config; used in place, never copied to outputs"),
    ]:
        p.add_argument("--" + name, metavar="FILE", help=helptext)
    p.add_argument("--content-wordlist", action="append", default=[], metavar="FILE", help="HTTP path wordlist; repeatable, independent of DNS wordlists")
    p.add_argument("--openapi", action="store_true", help="Discover OpenAPI/Swagger JSON and inventory methods and parameters")
    p.add_argument("--auth-file", metavar="JSON", help="Exact-origin header/localStorage profiles; kept outside run snapshots")
    p.add_argument("--browser", action="store_true", help="Optional Playwright Chromium: rendered links, fetch/XHR and WebSocket leads")
    p.add_argument("--browser-executable", help="Optional Chromium/Chrome executable; otherwise use installed Playwright Chromium")
    p.add_argument("--browser-pages", type=positive, default=20, help="Total browser page visits, including authentication contexts")
    p.add_argument("--browser-requests", type=positive, default=500, help="Total browser network requests; independent of native max-http")
    p.add_argument("--browser-wait", type=nonnegative_float, default=1.0, help="Seconds to observe dynamic page activity after DOM load")
    p.add_argument("--network-db", metavar="JSON", help="Offline ASN/CDN ranges; accepts cdncheck sources_data.json or networks records")
    p.add_argument("--cdn", action="store_true", help="Use the bundled cdncheck provider-range snapshot for offline CDN/cloud/WAF enrichment")
    p.add_argument("--asn", action="store_true", help="Enrich public IPs using Team Cymru DNS TXT metadata queries")
    p.add_argument("--resume", metavar="RUN_DIR", help="Resume a v5 checkpoint; require --authorized; optionally override --run-timeout or increase --max-http/--max-dns-queries")
    p.add_argument("--http-delay", type=nonnegative_float, default=0.0, help="Minimum seconds between native requests to the same origin")
    p.add_argument("--http-jitter", type=nonnegative_float, default=0.0, help="Random additional native per-origin delay, in seconds")
    p.add_argument("--backoff-max", type=nonnegative_float, default=60.0, help="Maximum adaptive 429/503 penalty; server Retry-After can exceed this")
    p.add_argument("--output", default="./recon-results", help="Parent for unique run directories")
    p.add_argument("--ports", type=ports, default=ports("80,443,8080,8443"), help="HTTP seed ports, not the Nmap scan range")
    p.add_argument("--scan-ports", type=ports, help="Nmap TCP ports/ranges; default --top-ports")
    p.add_argument("--top-ports", type=positive, default=1000, help="Nmap most common TCP ports when --scan-ports is absent")
    for name, default, helptext in [
        ("threads", 10, "DNS worker count"), ("dns-rate", 30, "DNS wire queries/sec across workers"),
        ("http-rate", 5, "HTTP request starts/sec; native web stage is deliberately sequential"),
        ("scan-rate", 50, "Nmap --max-rate for port scan packets; does not cap service probes"),
        ("timeout", 5, "Per DNS query / HTTP socket timeout in seconds"),
        ("request-timeout", 20, "Absolute native HTTP connect+header+body deadline in seconds"),
        ("stage-timeout", 900, "Maximum runtime of each external tool invocation in seconds"),
        ("run-timeout", 7200, "Overall pipeline wall-clock budget in seconds"),
        ("max-candidates", 20000, "Maximum host/IP assets, including feedback discoveries"),
        ("max-ips", 256, "Maximum explicit CIDR addresses and port-scan destination IPs"),
        ("max-dns-queries", 200000, "Total DNS queries including retries and wildcard tests"),
        ("max-http", 1000, "Maximum native HTTP requests across all rounds"),
        ("max-urls", 10000, "Maximum retained URL leads"),
        ("max-body", 1048576, "Maximum bytes read from an HTTP response"),
        ("max-wildcard-zones", 100, "Maximum parent zones with random-name wildcard baselines"),
        ("wildcard-tests", 2, "Random control names per parent zone; evidence is advisory"),
        ("crawl-depth", 2, "Maximum link traversal depth from each web seed"),
        ("redirects", 3, "Maximum scoped redirect hops"),
    ]:
        p.add_argument("--" + name, type=positive, default=default, help=helptext)
    p.add_argument("--feedback-rounds", type=nonnegative, default=1, help="Additional DNS/port/web rounds for newly observed names")
    p.add_argument("--recursive-depth", type=nonnegative, default=0, help="Wordlist generations below discovered parent domains")
    for name, default in [("nmap", "nmap"), ("subfinder", "subfinder"), ("gau", "gau"), ("httpx", "httpx")]:
        p.add_argument("--" + name + "-bin", default=os.environ.get(name.upper() + "_BIN", default), help="Executable for " + name)
    return p


class Policy:
    def __init__(self, args):
        self.domain = host(args.domain) if args.domain else None
        if self.domain and is_ip(self.domain):
            raise ValueError("Use --targets for IP addresses, not the domain positional argument")
        self.allow = [self.domain, "*." + self.domain] if self.domain else []
        if args.scope:
            self.allow = [rule(s) for _, s in lines(args.scope)]
            if not self.allow:
                raise ValueError("Scope file is empty")
        self.denied = []
        self.denied_ips = []
        self.ip_allow = []
        self.explicit_ips = set()
        self.private = args.allow_private
        if args.exclude:
            for _, s in lines(args.exclude):
                try:
                    self.denied_ips.append(ipaddress.ip_network(s, strict=False))
                except ValueError:
                    self.denied.append(rule(s))
        if args.ip_allow:
            self.ip_allow = [ipaddress.ip_network(s, strict=False) for _, s in lines(args.ip_allow)]
            if not self.ip_allow:
                raise ValueError("IP allow file is empty")

    def name(self, name):
        if is_ip(name):
            return name in self.explicit_ips and self.ip(name)
        return any(matches(name, x) for x in self.allow) and not any(matches(name, x) for x in self.denied)

    def ip(self, value):
        ip = ipaddress.ip_address(value)
        if ip.is_multicast or ip.is_unspecified or getattr(ip, "scope_id", None):
            return False
        if any(ip in n for n in self.denied_ips):
            return False
        if self.ip_allow and not any(ip in n for n in self.ip_allow):
            return False
        # Treat mapped IPv4 by both policies; never hide it behind an IPv6 literal.
        mapped = getattr(ip, "ipv4_mapped", None)
        if mapped and not self.ip(str(mapped)):
            return False
        return self.private or ip.is_global


class Limiter:
    def __init__(self, rate):
        self.delay = 1.0 / rate
        self.next = 0.0
        self.lock = threading.Lock()

    def wait(self):
        with self.lock:
            now = time.monotonic()
            wait = max(0.0, self.next - now)
            self.next = max(now, self.next) + self.delay
        if STOP.wait(wait):
            raise Interrupted()


class DNS:
    def __init__(self, pipeline):
        self.p = pipeline
        self.primary = self.servers(pipeline.a.resolvers)
        self.backup = self.servers(pipeline.a.trusted_resolvers) if pipeline.a.trusted_resolvers else []
        self.rate = Limiter(pipeline.a.dns_rate)
        self.lock = threading.Lock()
        self.count = 0

    @staticmethod
    def servers(path):
        import dns.resolver
        try:
            entries = [s for _, s in lines(path)] if path else list(dns.resolver.Resolver().nameservers)
        except dns.exception.DNSException as e:
            raise ValueError("Cannot load OS DNS servers; supply --resolvers FILE") from e
        result = []
        for entry in entries:
            parts = str(entry).rsplit("#", 1)
            ip = str(ipaddress.ip_address(parts[0]))
            port = int(parts[1]) if len(parts) == 2 else 53
            if not 1 <= port <= 65535:
                raise ValueError("Invalid DNS resolver port")
            result.append((ip, port))
        if not result:
            raise ValueError("No DNS resolvers configured")
        return result

    def wire(self, name, kind, server):
        import dns.exception
        import dns.flags
        import dns.message
        import dns.query
        import dns.rcode
        self.p.guard()
        with self.lock:
            if self.count >= self.p.a.max_dns_queries:
                raise BudgetExceeded("DNS query budget exhausted")
            self.count += 1
        self.rate.wait()
        self.p.guard()
        record = {"name": name, "type": kind, "resolver": "%s#%s" % server, "at": utc(), "answers": []}
        try:
            q = dns.message.make_query(name + ".", kind)
            timeout = min(self.p.a.timeout, max(0.01, self.p.deadline - time.monotonic()))
            r = dns.query.udp(q, server[0], port=server[1], timeout=timeout, ignore_unexpected=True)
            if r.flags & dns.flags.TC:
                with self.lock:
                    if self.count >= self.p.a.max_dns_queries:
                        raise BudgetExceeded("DNS TCP retry budget exhausted")
                    self.count += 1
                self.rate.wait()
                self.p.guard()
                timeout = min(self.p.a.timeout, max(0.01, self.p.deadline - time.monotonic()))
                r = dns.query.tcp(q, server[0], port=server[1], timeout=timeout)
            record["rcode"] = dns.rcode.to_text(r.rcode())
            for rrset in r.answer:
                for item in rrset:
                    record["answers"].append({"owner": str(rrset.name).rstrip("."), "type": dns.rdatatype.to_text(rrset.rdtype),
                                              "ttl": rrset.ttl, "value": item.to_text().rstrip(".")})
            record["outcome"] = ("answer" if any(x["type"] == kind for x in record["answers"]) else "nodata") if r.rcode() == 0 else record["rcode"].lower()
        except dns.exception.Timeout:
            record["outcome"] = "timeout"
        except (OSError, dns.exception.DNSException) as e:
            record.update(outcome="error", error=str(e))
        self.p.event("dns_query", record)
        return record

    def query(self, name, kind):
        attempts = []
        # A negative answer from the first server is never the only evidence
        # when an independent retry resolver has been supplied.
        for server in self.primary + self.backup:
            result = self.wire(name, kind, server)
            attempts.append(result)
            if result["outcome"] == "answer":
                break
        return {"type": kind, "outcome": attempts[-1]["outcome"], "attempts": attempts}

    def resolve(self, name, extra=False):
        observations = [self.query(name, kind) for kind in DNS_TYPES + (("MX", "NS", "TXT", "CAA", "SOA") if extra else ())]
        addresses, cnames = set(), set()
        for obs in observations:
            for attempt in obs["attempts"]:
                # Accept address RRs only along the queried name's CNAME chain.
                owners = {name}
                for _ in range(16):
                    before = len(owners)
                    for rr in attempt["answers"]:
                        if rr["type"] == "CNAME" and rr["owner"].lower() in owners:
                            owners.add(rr["value"].lower())
                            cnames.add(rr["value"].lower())
                    if len(owners) == before:
                        break
                for rr in attempt["answers"]:
                    if rr["type"] in ("A", "AAAA") and rr["owner"].lower() in owners:
                        try:
                            addresses.add(str(ipaddress.ip_address(rr["value"])))
                        except ValueError:
                            pass
        outcomes = {o["outcome"] for o in observations[:3]}
        state = "resolved" if addresses else "cname_without_address" if cnames else "nxdomain" if outcomes == {"nxdomain"} else "unresolved"
        return {"state": state, "addresses": sorted(addresses), "cnames": sorted(cnames), "observations": observations, "at": utc()}


class PageParser(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.forms = []
        self.title = ""
        self.in_title = False
        self.form = None
        self.base = None
        self.scripts = []
        self.in_script = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "title":
            self.in_title = True
        if tag == "script":
            self.in_script = True
        if tag == "base" and self.base is None:
            self.base = a.get("href")
        for key in ("href", "src"):
            if a.get(key) and tag != "base":
                self.links.append(a[key])
        if tag == "form":
            self.form = {"action": a.get("action", ""), "method": a.get("method", "GET").upper(), "fields": []}
            self.forms.append(self.form)
        if tag in ("input", "textarea", "select", "button") and self.form is not None and a.get("name"):
            # Do not persist prefilled values or credentials from forms.
            self.form["fields"].append({"name": a["name"], "type": a.get("type", tag)})

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False
        if tag == "form":
            self.form = None
        if tag == "script":
            self.in_script = False

    def handle_data(self, data):
        if self.in_title:
            self.title += data[:1000]
        if self.in_script:
            self.scripts.append(data)


class DeadlineSocket:
    """Nonblocking transport with both idle and absolute deadlines, including TLS."""
    def __init__(self, sock, deadline, idle_timeout):
        self.sock, self.deadline, self.idle_timeout = sock, deadline, idle_timeout

    def check(self, idle_deadline):
        if STOP.is_set():
            raise Interrupted()
        if time.monotonic() >= min(self.deadline, idle_deadline):
            raise TimeoutError("HTTP connection/request deadline exceeded")

    def wait(self, writing, idle_deadline):
        self.check(idle_deadline)
        timeout = min(0.1, max(0.0, min(self.deadline, idle_deadline) - time.monotonic()))
        select.select([] if writing else [self.sock], [self.sock] if writing else [], [self.sock], timeout)

    def operation(self, fn, writing=False):
        idle_deadline = time.monotonic() + self.idle_timeout
        while True:
            self.check(idle_deadline)
            try:
                return fn()
            except ssl.SSLWantReadError:
                self.wait(False, idle_deadline)
            except ssl.SSLWantWriteError:
                self.wait(True, idle_deadline)
            except BlockingIOError:
                self.wait(writing, idle_deadline)

    def connect(self, ip, port):
        error = self.sock.connect_ex((ip, port))
        if error == 0:
            return
        if error not in (errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY, 10035, 10036, 10037):
            raise OSError(error, os.strerror(error))
        idle_deadline = time.monotonic() + self.idle_timeout
        while True:
            self.check(idle_deadline)
            _, writable, exceptional = select.select([], [self.sock], [self.sock], 0.1)
            if writable or exceptional:
                error = self.sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                if error:
                    raise OSError(error, os.strerror(error))
                return

    def sendall(self, data):
        remaining = memoryview(data)
        while remaining:
            sent = self.operation(lambda: self.sock.send(remaining), writing=True)
            if not sent:
                raise ConnectionError("Connection closed while sending request")
            remaining = remaining[sent:]

    def makefile(self, mode):
        transport = self
        class Reader(io.RawIOBase):
            def readable(self):
                return True

            def readinto(self, buffer):
                return transport.operation(lambda: transport.sock.recv_into(buffer))
        return io.BufferedReader(Reader())


def fetch(url, ip, args, deadline=None, headers=None):
    """A pinned GET: Host and TLS SNI stay on the URL hostname; no OS DNS/proxy."""
    u = urllib.parse.urlsplit(url)
    port = u.port or (443 if u.scheme == "https" else 80)
    outcome = {"url": url, "ip": ip, "port": port, "at": utc(), "method": "GET", "outcome": "error"}
    start = time.monotonic()
    sock = None
    response = None
    try:
        family = socket.AF_INET6 if ":" in ip else socket.AF_INET
        sock = socket.socket(family, socket.SOCK_STREAM)
        sock.setblocking(False)
        remaining = min(args.request_timeout, max(0.01, deadline - time.monotonic())) if deadline else args.request_timeout
        request_deadline = time.monotonic() + remaining
        transport = DeadlineSocket(sock, request_deadline, args.timeout)
        transport.connect(ip, port)
        if u.scheme == "https":
            ctx = ssl.create_default_context() if args.tls_verify else ssl._create_unverified_context()
            sock = ctx.wrap_socket(sock, server_hostname=u.hostname, do_handshake_on_connect=False)
            transport.sock = sock
            transport.operation(sock.do_handshake)
            cert = sock.getpeercert(binary_form=True)
            outcome["tls"] = {"protocol": sock.version(), "cipher": sock.cipher(),
                              "certificate_sha256": digest(cert) if cert else None,
                              "verification": "verified" if args.tls_verify else "not_requested"}
            if cert:
                from cryptography import x509
                decoded = x509.load_der_x509_certificate(cert)
                outcome["tls"].update(subject=decoded.subject.rfc4514_string(), issuer=decoded.issuer.rfc4514_string(),
                                      not_before=decoded.not_valid_before_utc.isoformat(), not_after=decoded.not_valid_after_utc.isoformat())
                with contextlib.suppress(x509.ExtensionNotFound):
                    san = decoded.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
                    outcome["tls"]["dns_names"] = san.get_values_for_type(x509.DNSName)
        request_path = u.path or "/"
        if u.query:
            request_path += "?" + u.query
        request = ("GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: ReconPipeline/%s\r\n"
                   "Accept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n") % (request_path, u.netloc, VERSION)
        if headers:
            request = request[:-2] + "".join("%s: %s\r\n" % (k, v) for k, v in headers.items()) + "\r\n"
        transport.sendall(request.encode("ascii"))
        response = http.client.HTTPResponse(transport)
        response.begin()
        if not 100 <= response.status <= 599:
            raise http.client.HTTPException("Invalid HTTP status code")
        body = response.read(args.max_body + 1)
        transport.check(request_deadline)
        truncated = len(body) > args.max_body
        body = body[:args.max_body]
        headers = {k.lower(): v for k, v in response.getheaders() if k.lower() != "set-cookie"}
        content_type = headers.get("content-type", "")
        charset = re.search(r"charset\s*=\s*([^\s;]+)", content_type, re.I)
        try:
            text_body = body.decode(charset.group(1).strip('"') if charset else "utf-8", "replace")
        except LookupError:
            text_body = body.decode("utf-8", "replace")
        encoding = headers.get("content-encoding", "identity").lower()
        if encoding not in ("", "identity"):
            text_body = ""
        outcome.update(outcome="response", status_code=response.status, headers=headers,
                       body_bytes=len(body), body_truncated=truncated, body_sha256=digest(body),
                       body_hash_scope="prefix" if truncated else "full", content_type=content_type,
                       body_parse_state="text" if encoding in ("", "identity") else "unsupported_content_encoding")
        return outcome, text_body
    except ssl.SSLCertVerificationError as e:
        outcome.update(outcome="tls_error", error=str(e))
    except ssl.SSLError as e:
        outcome.update(outcome="tls_error", error=str(e))
    except (socket.timeout, TimeoutError) as e:
        outcome.update(outcome="timeout", error=str(e))
    except ConnectionRefusedError as e:
        outcome.update(outcome="connection_refused", error=str(e))
    except (OSError, http.client.HTTPException, UnicodeError) as e:
        outcome.update(outcome="connection_error", error=str(e))
    finally:
        if response:
            response.close()
        if sock:
            sock.close()
        outcome["elapsed_ms"] = round((time.monotonic() - start) * 1000)
    return outcome, ""


def parse_nmap(path, expected):
    data = path.read_bytes()
    if b"<!ENTITY" in data:
        raise ValueError("Unexpected XML entity declarations")
    root = ET.fromstring(data)
    if root.tag != "nmaprun" or root.find("runstats/finished") is None:
        raise ValueError("Incomplete Nmap XML")
    finished = root.find("runstats/finished")
    if finished.get("exit") != "success":
        raise ValueError("Nmap XML reports unsuccessful completion")
    result = {}
    for node in root.findall("host"):
        ips = [x.get("addr") for x in node.findall("address") if x.get("addrtype") in ("ipv4", "ipv6")]
        for ip in ips:
            ip = str(ipaddress.ip_address(ip))
            if ip not in expected:
                raise ValueError("Nmap emitted an unexpected destination: " + ip)
            status = node.find("status")
            entry = {"state": "completed" if node.find("ports") is not None else "incomplete",
                     "host_status": dict(status.attrib) if status is not None else {},
                     "ports": [], "extraports": []}
            for port in node.findall("ports/port"):
                state = port.find("state")
                service = port.find("service")
                entry["ports"].append({"protocol": port.get("protocol"), "port": int(port.get("portid")),
                                       "state": dict(state.attrib) if state is not None else {},
                                       "service": dict(service.attrib) if service is not None else {},
                                       "cpe": [x.text for x in port.findall("service/cpe")]})
            for extra in node.findall("ports/extraports"):
                entry["extraports"].append({"state": extra.get("state"), "count": int(extra.get("count")),
                                           "reasons": [dict(x.attrib) for x in extra]})
            result[ip] = entry
    for ip in expected:
        result.setdefault(ip, {"state": "not_reported", "ports": [], "extraports": []})
    return result


class Pipeline:
    def __init__(self, args, policy, seeds, words, tools):
        self.a, self.policy, self.seeds, self.words, self.tools = args, policy, seeds, words, tools
        base = Path(args.output).resolve()
        base.mkdir(parents=True, exist_ok=True)
        self.run = Path(args.resume).resolve() if args.resume else Path(tempfile.mkdtemp(prefix=(policy.domain or "ip-inventory") + "_" + datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_", dir=str(base)))
        self.store = StateStore(self.run)
        for sub in ("raw", "logs", "inputs"):
            (self.run / sub).mkdir(exist_ok=True)
        self.lock = threading.RLock()
        self.assets, self.urls, self.ips, self.wildcards = {}, {}, {}, {}
        self.http, self.stages, self.warnings, self.rejections = [], [], [], []
        self.attempted = set()
        self.generated_zones = set()
        self.start = utc()
        self.deadline = time.monotonic() + args.run_timeout
        self.http_limiter = Limiter(args.http_rate)
        self.pacer = AdaptivePacer(args.http_delay, args.http_jitter, args.backoff_max)
        self.progress = {"collection": False, "round": 0, "httpx": False}
        self.resume_count = 0
        self.http_count = 0
        self.dns = DNS(self) if args.active else None
        self.status, self.error = "running", None
        self.events = (self.run / "events.jsonl").open("a", encoding="utf-8", buffering=1, newline="\n")
        self.discovery = Discovery(self)
        self.input_hashes = {}
        if args.resume:
            state = self.store.read()
            for key in ("assets", "urls", "ips", "wildcards", "http", "stages", "warnings", "rejections", "start", "input_hashes", "progress", "http_count"):
                setattr(self, key, state[key])
            self.discovery.state = state["discovery"]
            self.attempted = {tuple(item) for item in state["attempted"]}
            for response in self.http:
                self.store.finish_job("http", response["url"] + "|" + response["ip"], {"outcome": response["outcome"]})
            self.generated_zones = set(state["generated_zones"])
            self.pacer.origins = state["cooldowns"]
            self.resume_count = state["resume_count"] + 1
            if args.max_http > state["settings"]["max_http"] or args.max_dns_queries > state["settings"]["max_dns_queries"]:
                self.progress.update(round=0, httpx=False)
                self.warnings = [w for w in self.warnings if w != "HTTP request budget reached; unvisited URLs are not negative results"]
            if self.dns:
                self.dns.count = state["dns_count"]
            for stage in self.stages:
                if stage["state"] == "running":
                    stage.update(state="interrupted", finished_at=utc(), error="Process ended before stage commit", resumed=True)
            self.say("Resuming: " + str(self.run))
            self.event("resumed", {"resume_count": self.resume_count})
            return
        for key in ("targets", "passive_file", "url_file", "wordlist", "scope", "exclude", "ip_allow", "resolvers", "trusted_resolvers", "content_wordlist", "network_db"):
            values = getattr(args, key)
            for i, filename in enumerate(values if isinstance(values, list) else [values] if values else []):
                target = self.run / "inputs" / (key + "_" + str(i) + ".txt")
                shutil.copyfile(filename, target)
                self.input_hashes[target.name] = digest(target.read_bytes())
        shutil.copyfile(__file__, self.run / "inputs" / "recon_pipeline.py")
        self.input_hashes["recon_pipeline.py"] = digest(Path(__file__).read_bytes())
        (self.run / "inputs" / "empty.yaml").write_text("{}\n", encoding="utf-8")
        (self.run / "inputs" / "empty.toml").write_text("", encoding="utf-8")
        shutil.copyfile(Path(__file__).with_name("recon_runtime.py"), self.run / "inputs" / "recon_runtime.py")
        self.input_hashes["recon_runtime.py"] = digest(Path(__file__).with_name("recon_runtime.py").read_bytes())
        for module in Path(__file__).parent.glob("recon_*.py"):
            shutil.copyfile(module, self.run / "inputs" / module.name)
            self.input_hashes[module.name] = digest(module.read_bytes())
        self.checkpoint()
        self.say("Run directory: " + str(self.run))

    def checkpoint(self):
        state = {key: getattr(self, key) for key in (
            "assets", "urls", "ips", "wildcards", "http", "stages", "warnings", "rejections", "start",
            "input_hashes", "progress", "http_count", "resume_count")}
        settings = vars(self.a).copy()
        settings["output"] = str(self.run.parent)
        for name, tool in self.tools.items():
            if "path" in tool:
                settings[name + "_bin"] = tool["path"]
        # Resume never depends on the original wordlists or policy file locations.
        for key in ("targets", "passive_file", "url_file", "wordlist", "scope", "exclude", "ip_allow", "resolvers", "trusted_resolvers", "content_wordlist", "network_db"):
            value = settings[key]
            paths = [str(self.run / "inputs" / (key + "_" + str(i) + ".txt")) for i in range(len(value) if isinstance(value, list) else 1 if value else 0)]
            settings[key] = paths if isinstance(value, list) else paths[0] if paths else None
        for key in ("baseline", "provider_config", "auth_file"):
            if settings[key]:
                settings[key] = str(Path(settings[key]).resolve())
        state["discovery"] = self.discovery.state
        state["auth_sha256"] = digest(Path(self.a.auth_file).read_bytes()) if self.a.auth_file else None
        state.update(version=VERSION, settings=settings, tools=self.tools, attempted=sorted(self.attempted),
                     generated_zones=sorted(self.generated_zones), cooldowns=self.pacer.origins,
                     dns_count=self.dns.count if self.dns else 0)
        self.store.save(state)

    def close(self):
        self.events.close()
        self.store.close()

    def say(self, message):
        print(message, file=sys.stderr, flush=True)

    def guard(self):
        if STOP.is_set():
            raise Interrupted()
        if time.monotonic() >= self.deadline:
            raise BudgetExceeded("Overall run timeout")

    @contextlib.contextmanager
    def phase(self, name):
        record = {"stage": name, "started_at": utc(), "state": "running"}
        self.stages.append(record)
        self.event("stage_start", record)
        try:
            yield
            self.guard()
            record["state"] = "completed"
        except Interrupted:
            record["state"] = "interrupted"
            raise
        except BudgetExceeded as e:
            record.update(state="timed_out" if str(e) == "Overall run timeout" else "budget_exhausted", error=str(e))
            raise
        except Exception as e:
            record.update(state="failed", error=str(e))
            raise
        finally:
            record["finished_at"] = utc()
            self.event("stage_end", record)

    def event(self, kind, data):
        if hasattr(self, "discovery"):
            data = self.discovery.auth.redact(data)
        with self.lock:
            self.events.write(json.dumps({"schema": SCHEMA, "kind": kind, "at": utc(), "data": data}, ensure_ascii=False) + "\n")

    def warn(self, message):
        if message not in self.warnings:
            self.warnings.append(message)
            self.event("warning", {"message": message})

    def reject(self, value, reason, source):
        record = {"value": value, "reason": reason, "source": source}
        if len(self.rejections) < self.a.max_urls:
            self.rejections.append(record)
        self.event("rejected", record)

    def add_asset(self, name, source):
        try:
            name = host(name)
        except ValueError as e:
            self.reject(name, str(e), source)
            return None
        if not self.policy.name(name):
            self.reject(name, "outside_policy", source)
            return None
        if name not in self.assets:
            if len(self.assets) >= self.a.max_candidates:
                self.warn("Candidate limit reached; coverage is incomplete")
                return None
            self.assets[name] = {"name": name, "kind": "ip" if is_ip(name) else "hostname", "sources": [],
                                 "first_seen": utc(), "last_seen": utc(), "dns": {"state": "not_run"}, "wildcard": "not_tested"}
        asset = self.assets[name]
        if source not in asset["sources"]:
            asset["sources"].append(source)
        asset["last_seen"] = utc()
        return asset

    def add_url(self, value, source, base=None, method="GET", fields=None, probe=True, depth=0, redirects=0):
        if self.discovery.auth.redact(value) != value:
            self.reject("[REDACTED]", "credential_in_discovered_url", source)
            return None
        try:
            value = url_normalize(value, base)
            name = urllib.parse.urlsplit(value).hostname
        except ValueError as e:
            self.reject(value, str(e), source)
            return None
        if not self.policy.name(name):
            self.reject(value, "outside_policy", source)
            return None
        if value not in self.urls:
            if len(self.urls) >= self.a.max_urls:
                self.warn("URL limit reached; coverage is incomplete")
                return None
            self.urls[value] = {"url": value, "host": name, "sources": [], "methods": [], "forms": [],
                                "parameters": sorted(set(urllib.parse.parse_qs(urllib.parse.urlsplit(value).query, keep_blank_values=True))),
                                "probe_eligible": False, "state": "not_probed", "depth": depth, "redirect_hops": redirects}
        row = self.urls[value]
        for key, entry in (("sources", source), ("methods", method)):
            if entry not in row[key]:
                row[key].append(entry)
        if fields is not None:
            form = {"method": method, "fields": fields}
            if form not in row["forms"]:
                row["forms"].append(form)
        if probe and method == "GET":
            if not row["probe_eligible"] or (depth, redirects) < (row["depth"], row["redirect_hops"]):
                row["depth"], row["redirect_hops"] = depth, redirects
            row["probe_eligible"] = True
        self.add_asset(name, "url:" + source)
        return value

    def external(self, stage, cmd):
        self.guard()
        n = len(self.stages)
        name = "%02d_%s_%s" % (n, stage, uuid.uuid4().hex[:8])
        out = self.run / "raw" / (name + ".stdout")
        err = self.run / "logs" / (name + ".stderr")
        record = {"stage": stage, "command": cmd, "started_at": utc(), "state": "running", "stdout": str(out.relative_to(self.run)), "stderr": str(err.relative_to(self.run))}
        self.stages.append(record)
        self.event("stage_start", record)
        deadline = min(self.deadline, time.monotonic() + self.a.stage_timeout)
        self.say("Running " + stage)
        proc = None
        try:
            with out.open("wb") as stdout, err.open("wb") as stderr:
                proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                        start_new_session=(os.name != "nt"), cwd=str(self.run),
                                        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                while proc.poll() is None:
                    self.guard()
                    if time.monotonic() >= deadline:
                        raise TimeoutError("External stage timeout: " + stage)
                    STOP.wait(0.1)
                record.update(exit_code=proc.returncode, state="completed" if proc.returncode == 0 else "failed")
        except (Interrupted, BudgetExceeded):
            record["state"] = "interrupted" if STOP.is_set() else "timed_out"
            raise
        except (OSError, TimeoutError) as e:
            record.update(state="timed_out" if isinstance(e, TimeoutError) else "failed", error=str(e))
        finally:
            if proc and proc.poll() is None:
                if os.name == "nt":
                    # These adapters do not start child processes on Windows.
                    proc.kill()
                else:
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        with contextlib.suppress(ProcessLookupError):
                            os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            record["finished_at"] = utc()
            self.event("stage_end", record)
        if record["state"] != "completed":
            self.warn(stage + " did not complete; raw partial output retained but not promoted")
            return None
        return out

    def collect(self):
        for name, source, is_url in self.seeds:
            if is_url:
                self.add_url(name, source, probe=source != "archive_import" or self.a.probe_archives)
            else:
                self.add_asset(name, source)
        if not self.a.skip_passive and not self.a.passive_file and self.policy.domain:
            cmd = [self.tools["subfinder"]["path"], "-d", self.policy.domain, "-oJ", "-cs", "-nc", "-duc", "-rl", str(self.a.http_rate),
                   "-config", str(self.run / "inputs" / "empty.yaml"), "-timeout", str(self.a.timeout), "-max-time", str(max(1, self.a.stage_timeout // 60))]
            if self.a.subfinder_all:
                cmd.append("-all")
            if self.a.provider_config:
                cmd += ["-pc", str(Path(self.a.provider_config).resolve())]
            out = self.external("subfinder", cmd)
            if out:
                try:
                    staged = []
                    for _, line in lines(out):
                        row = json.loads(line)
                        name = row["host"]
                        sources = row.get("sources") or [row.get("source", "unknown")]
                        if isinstance(sources, str):
                            sources = [sources]
                        for source in sources:
                            staged.append((name, "subfinder:" + str(source)))
                    for name, source in staged:
                        self.add_asset(name, source)
                except (ValueError, KeyError, TypeError) as e:
                    self.stages[-1].update(state="invalid_output", error=str(e))
                    self.warn("subfinder output contained invalid JSON records")
            self.warn("Passive source completeness is unknown; provider errors and missing API keys require reviewing stderr")
        if self.a.archive and self.policy.domain:
            out = self.external("gau", [self.tools["gau"]["path"], "--subs", "--threads", "1", "--timeout", str(self.a.timeout),
                                        "--config", str(self.run / "inputs" / "empty.toml"), self.policy.domain])
            if out:
                for _, url in lines(out):
                    self.add_url(url, "gau", probe=self.a.probe_archives)
        if self.a.active:
            self.generate([self.policy.domain] if self.policy.domain else [])

    def generate(self, zones):
        if self.a.no_bruteforce or not self.words:
            return
        for zone in sorted(set(zones)):
            if zone in self.generated_zones:
                continue
            self.generated_zones.add(zone)
            excluded = 0
            for word in self.words:
                if len(self.assets) >= self.a.max_candidates:
                    self.warn("Candidate limit reached during wordlist generation")
                    return
                candidate = word + "." + zone
                if not self.policy.name(candidate):
                    excluded += 1
                    continue
                self.add_asset(candidate, "wordlist:" + zone)
            self.event("wordlist_generation", {"zone": zone, "entries": len(self.words), "excluded_by_policy": excluded})

    def resolve_round(self):
        pending = [a for a in self.assets.values() if a["dns"]["state"] == "not_run"]
        self.say("Resolving %d new assets (A, AAAA, CNAME)" % len(pending))
        for asset in pending:
            if asset["kind"] == "ip":
                asset["dns"] = {"state": "literal", "addresses": [asset["name"]], "cnames": [], "observations": []}
        names = [a["name"] for a in pending if a["kind"] != "ip"]
        unresolved = []
        for name in names:
            cached = self.store.cached_job("dns", name)
            if cached is not None:
                self.assets[name]["dns"] = cached
            else:
                unresolved.append(name)
        names = unresolved
        # Bounded batches avoid queuing thousands of uncancellable futures.
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.a.threads) as pool:
            for offset in range(0, len(names), self.a.threads):
                self.guard()
                for name in names[offset:offset + self.a.threads]:
                    self.store.start_job("dns", name)
                tasks = {pool.submit(self.dns.resolve, n, n == self.policy.domain): n for n in names[offset:offset + self.a.threads]}
                for future in concurrent.futures.as_completed(tasks):
                    name = tasks[future]
                    self.assets[name]["dns"] = future.result()
                    self.store.finish_job("dns", name, self.assets[name]["dns"])
                    self.event("asset_dns", {"name": name, "dns": self.assets[name]["dns"]})
        for asset in pending:
            for cname in asset["dns"].get("cnames", []):
                self.add_asset(cname, "cname:" + asset["name"])
            for observation in asset["dns"].get("observations", []):
                for attempt in observation["attempts"]:
                    for rr in attempt["answers"]:
                        if rr["type"] in ("MX", "NS"):
                            self.add_asset(rr["value"].split()[-1], rr["type"].lower() + ":" + asset["name"])
            for ip in asset["dns"].get("addresses", []):
                if ip not in self.ips:
                    self.ips[ip] = {"ip": ip, "version": ipaddress.ip_address(ip).version, "names": [],
                                    "allowed": self.policy.ip(ip), "scan": {"state": "not_run", "ports": []}}
                if asset["name"] not in self.ips[ip]["names"]:
                    self.ips[ip]["names"].append(asset["name"])
            if asset["dns"]["state"] == "cname_without_address":
                asset["lead"] = "CNAME without usable A/AAAA; investigate configuration, not proof of takeover"
        if self.a.reverse_dns:
            for ip, entry in self.ips.items():
                if entry["allowed"] and "ptr" not in entry:
                    entry["ptr"] = self.dns.query(ipaddress.ip_address(ip).reverse_pointer, "PTR")
                    for attempt in entry["ptr"]["attempts"]:
                        for rr in attempt["answers"]:
                            if rr["type"] == "PTR":
                                self.add_asset(rr["value"], "ptr:" + ip)
        self.wildcard_round(pending)
        return pending

    def wildcard_round(self, assets):
        for asset in assets:
            name = asset["name"]
            if is_ip(name) or "." not in name or name == self.policy.domain:
                continue
            zone = name.split(".", 1)[1]
            if zone not in self.wildcards:
                if len(self.wildcards) >= self.a.max_wildcard_zones:
                    asset["wildcard"] = "unknown_budget"
                    self.warn("Wildcard parent-zone budget reached")
                    continue
                controls = ["rp-" + uuid.uuid4().hex[:18] + "." + zone for _ in range(self.a.wildcard_tests)]
                if not all(self.policy.name(x) for x in controls):
                    self.wildcards[zone] = {"state": "unknown_policy", "controls": []}
                else:
                    observations = [self.dns.resolve(x) for x in controls]
                    signatures = [set(o["addresses"] + o["cnames"]) for o in observations]
                    self.wildcards[zone] = {"state": "detected" if all(signatures) else "not_observed" if all(o["state"] == "nxdomain" for o in observations) else "inconclusive",
                                           "controls": [{"name": n, "dns": o} for n, o in zip(controls, observations)],
                                           "values": sorted(set().union(*signatures))}
            baseline = self.wildcards[zone]
            values = set(asset["dns"].get("addresses", []) + asset["dns"].get("cnames", []))
            asset["wildcard"] = "possible_match" if values.intersection(baseline.get("values", [])) else baseline["state"]
        # Wildcard matches remain in the pipeline: real vhosts may share that IP.

    def scan_round(self, round_number):
        if not self.a.port_scan:
            return
        previously = sum(i["scan"]["state"] != "not_run" for i in self.ips.values())
        todo = [ip for ip, a in self.ips.items() if a["allowed"] and a["scan"]["state"] == "not_run"]
        selected = sorted(todo)[:max(0, self.a.max_ips - previously)]
        if len(selected) < len(todo):
            self.warn("Port-scan IP budget reached; remaining IPs were not scanned")
        for version in (4, 6):
            group = [ip for ip in selected if ipaddress.ip_address(ip).version == version]
            if not group:
                continue
            batch = "nmap_%d_v%d_%s" % (round_number, version, uuid.uuid4().hex[:8])
            inputs = self.run / "inputs" / (batch + ".txt")
            inputs.write_text("\n".join(group) + "\n", encoding="ascii")
            xml = self.run / "raw" / (batch + ".xml.part")
            cmd = [self.tools["nmap"]["path"], "-sT", "-Pn", "-n", "--unprivileged", "--max-rate", str(self.a.scan_rate),
                   "--max-retries", "2", "--host-timeout", str(self.a.stage_timeout) + "s", "-iL", str(inputs), "-oX", str(xml.relative_to(self.run))]
            if version == 6:
                cmd.append("-6")
            if self.a.scan_ports:
                cmd += ["-p", port_expression(self.a.scan_ports)]
            else:
                cmd += ["--top-ports", str(self.a.top_ports)]
            if self.a.service_detection:
                cmd += ["-sV", "--version-light"]
            output = self.external("nmap", cmd)
            for ip in group:
                self.ips[ip]["scan"] = {"state": "failed", "ports": []}
            if output:
                try:
                    parsed = parse_nmap(xml, set(group))
                    for ip, result in parsed.items():
                        self.ips[ip]["scan"] = result
                        if result["state"] != "completed":
                            self.warn("Nmap did not fully report host " + ip)
                    xml.rename(xml.with_suffix(""))
                except (OSError, ValueError, ET.ParseError) as e:
                    self.stages[-1].update(state="invalid_output", error=str(e))
                    self.warn("Nmap output was incomplete or invalid; see retained XML")
            self.checkpoint()

    def seed_web(self, assets):
        for asset in assets:
            name = asset["name"]
            if not asset["dns"].get("addresses"):
                continue
            ports_to_try = set(self.a.ports)
            for ip in asset["dns"]["addresses"]:
                for item in self.ips[ip]["scan"].get("ports", []):
                    if item["state"].get("state") != "open" or item["protocol"] != "tcp":
                        continue
                    if "http" in item["service"].get("name", "") or self.a.probe_all_open:
                        ports_to_try.add(item["port"])
            authority = "[" + name + "]" if ":" in name else name
            for port in sorted(ports_to_try):
                for scheme in ("http", "https"):
                    self.add_url("%s://%s:%d/" % (scheme, authority, port), "web_seed")

    def web_round(self):
        queue = collections.deque()
        scheduled = set()

        def enqueue(url, depth=None, redirects=None):
            if url in scheduled or not url:
                return
            row = self.urls[url]
            depth = row["depth"] if depth is None else depth
            redirects = row["redirect_hops"] if redirects is None else redirects
            if not row["probe_eligible"]:
                return
            asset = self.assets.get(row["host"])
            if not asset:
                return
            addresses = asset["dns"].get("addresses", [])
            if not addresses:
                row["state"] = "dns_" + asset["dns"]["state"]
                return
            allowed = [ip for ip in addresses if self.policy.ip(ip)]
            if not allowed:
                row["state"] = "blocked_ip_policy"
                return
            scheduled.add(url)
            for ip in allowed:
                if (url, ip) not in self.attempted:
                    queue.append((url, ip, depth, redirects))

        for url in list(self.urls):
            enqueue(url)
        while queue:
            self.guard()
            url, ip, depth, redirect_count = queue.popleft()
            if (url, ip) in self.attempted:
                continue
            if self.http_count >= self.a.max_http:
                self.warn("HTTP request budget reached; unvisited URLs are not negative results")
                return
            origin_key = origin(url)
            wait = self.pacer.ready_in(origin_key)
            if wait:
                queue.append((url, ip, depth, redirect_count))
                # Rotate cooled origins so unrelated destinations can still make progress.
                minimum = min(self.pacer.ready_in(origin(item[0])) for item in queue)
                if minimum:
                    STOP.wait(min(minimum, 0.1))
                continue
            self.http_limiter.wait()
            self.guard()
            self.attempted.add((url, ip))
            self.http_count += 1
            self.store.start_job("http", url + "|" + ip)
            try:
                response, body = fetch(url, ip, self.a, self.deadline)
            except BaseException:
                self.attempted.discard((url, ip))
                raise
            response["pacing_delay"] = self.pacer.observe(origin_key, response)
            response["depth"] = depth
            response["redirect_hops"] = redirect_count
            self.http.append(response)
            self.discovery.observe(response, body)
            for discovered in list(self.urls):
                enqueue(discovered)
            row = self.urls[url]
            row["state"] = "live" if response["outcome"] == "response" or row["state"] == "live" else response["outcome"]
            for name in response.get("tls", {}).get("dns_names", []):
                if not name.startswith("*."):
                    self.add_asset(name, "tls_san:" + url)
            if response["outcome"] != "response":
                self.event("http", response)
                self.checkpoint()
                self.store.finish_job("http", url + "|" + ip, {"outcome": response["outcome"]})
                continue
            page = PageParser()
            mime = response.get("content_type", "").lower()
            is_html = "html" in mime or (not mime and body.lstrip().startswith("<"))
            if is_html:
                page.feed(body)
                response["title"] = " ".join(page.title.split())[:500]
            location = response["headers"].get("location")
            if location and response["status_code"] in (301, 302, 303, 307, 308):
                dest = self.add_url(location, "redirect:" + url, base=url, depth=depth, redirects=redirect_count + 1,
                                    probe=redirect_count < self.a.redirects)
                response["redirect"] = {"location": location, "url": dest,
                                        "state": "outside_policy_or_invalid" if not dest else "hop_limit" if redirect_count >= self.a.redirects else "queued"}
                if dest and redirect_count < self.a.redirects:
                    enqueue(dest, depth, redirect_count + 1)
            if self.a.crawl and depth < self.a.crawl_depth:
                base = url
                if page.base:
                    with contextlib.suppress(ValueError):
                        base = url_normalize(page.base, url)
                for link in page.links:
                    dest = self.add_url(link, "html:" + url, base=base, depth=depth + 1)
                    if dest:
                        enqueue(dest, depth + 1)
                for form in page.forms:
                    self.add_url(form["action"] or url, "form:" + url, base=base, method=form["method"], fields=form["fields"], probe=False)
                javascript = body if "javascript" in mime or urllib.parse.urlsplit(url).path.endswith(".js") else "\n".join(page.scripts)
                if javascript:
                    for link in re.findall(r'''["']((?:https?://|/)[^"'<>\s]{1,2048})["']''', javascript):
                        dest = self.add_url(link, "js_hint:" + url, base=url, depth=depth + 1)
                        if dest:
                            enqueue(dest, depth + 1)
                path = urllib.parse.urlsplit(url).path
                if path == "/robots.txt":
                    for link in re.findall(r"(?im)^\s*(?:allow|disallow|sitemap)\s*:\s*(\S+)", body):
                        if "*" not in link and "$" not in link:
                            dest = self.add_url(link, "robots:" + url, base=url, depth=depth + 1)
                            if dest:
                                enqueue(dest, depth + 1)
                if "xml" in mime or path.endswith(".xml"):
                    try:
                        tree = ET.fromstring(body)
                        for node in tree.iter():
                            if node.tag.rsplit("}", 1)[-1] == "loc" and node.text:
                                dest = self.add_url(node.text.strip(), "sitemap:" + url, base=url, depth=depth + 1)
                                if dest:
                                    enqueue(dest, depth + 1)
                    except ET.ParseError:
                        pass
                if depth == 0 and path == "/":
                    for path in ("/robots.txt", "/sitemap.xml"):
                        dest = self.add_url(path, "known_file:" + url, base=url, depth=depth + 1)
                        if dest:
                            enqueue(dest, depth + 1)
            self.event("http", response)
            self.checkpoint()
            self.store.finish_job("http", url + "|" + ip, {"outcome": response["outcome"]})

    def authenticated_round(self):
        if not self.discovery.auth.profiles:
            return
        for url, row in list(self.urls.items()):
            headers = self.discovery.auth.headers(url)
            if not headers or not row["probe_eligible"]:
                continue
            for ip in self.assets.get(row["host"], {}).get("dns", {}).get("addresses", []):
                key = url + "|" + ip
                if key in self.discovery.state["auth_done"] or not self.policy.ip(ip):
                    continue
                if self.http_count >= self.a.max_http:
                    self.warn("HTTP request budget reached; unvisited URLs are not negative results")
                    return
                self.guard()
                while self.pacer.ready_in(origin(url)):
                    self.guard()
                    STOP.wait(min(0.1, self.pacer.ready_in(origin(url))))
                self.http_limiter.wait()
                self.guard()
                self.http_count += 1
                response, body = fetch(url, ip, self.a, self.deadline, headers=headers)
                response["context"] = "authenticated"
                response["pacing_delay"] = self.pacer.observe(origin(url), response)
                response["depth"] = row["depth"]
                response = self.discovery.auth.redact(response)
                body = self.discovery.auth.redact(body)
                self.discovery.state["authenticated"].append(response)
                self.discovery.observe(response, body, "authenticated")
                if response["outcome"] == "response":
                    if self.a.crawl and row["depth"] < self.a.crawl_depth:
                        page = PageParser()
                        page.feed(body)
                        for link in page.links:
                            self.add_url(link, "authenticated_html:" + url, base=url, depth=row["depth"] + 1)
                    location = response.get("headers", {}).get("location")
                    if location and response.get("status_code") in (301, 302, 303, 307, 308) and row["redirect_hops"] < self.a.redirects:
                        self.add_url(location, "authenticated_redirect:" + url, base=url, redirects=row["redirect_hops"] + 1)
                self.discovery.state["auth_done"].append(key)
                self.event("authenticated_http", response)
                self.checkpoint()

    def httpx(self):
        if not self.a.httpx_enrich:
            return
        live = sorted({r["url"] for r in self.http if r["outcome"] == "response"})
        if not live:
            return
        path = self.run / "inputs" / "httpx_urls.txt"
        path.write_text("\n".join(live) + "\n", encoding="utf-8")
        allowed = sorted({r["ip"] for r in self.http if r["outcome"] == "response"})
        ip_path = self.run / "inputs" / "httpx_ips.txt"
        ip_path.write_text("\n".join(allowed) + "\n", encoding="ascii")
        resolver_path = self.run / "inputs" / "httpx_resolvers.txt"
        resolver_path.write_text("\n".join("udp:%s:%d" % (("[" + ip + "]") if ":" in ip else ip, port) for ip, port in self.dns.primary) + "\n", encoding="ascii")
        cmd = [self.tools["httpx"]["path"], "-l", str(path), "-j", "-silent", "-nc", "-duc", "-no-stdin", "-nfs",
               "-sc", "-title", "-td", "-ip", "-cname", "-tls-grab", "-probe", "-pa", "-fr=false", "-fhr=false",
               "-tls-probe=false", "-csp-probe=false", "-rl", str(self.a.http_rate), "-t", str(self.a.threads),
               "-timeout", str(self.a.timeout), "-retries", "0", "-rstr", str(self.a.max_body),
               "-allow", str(ip_path), "-r", str(resolver_path), "-config", str(self.run / "inputs" / "empty.yaml")]
        out = self.external("httpx", cmd)
        enrichments = []
        if out:
            try:
                for _, line in lines(out):
                    row = json.loads(line)
                    normalized = url_normalize(row["url"])
                    if normalized not in live:
                        raise ValueError("httpx returned an unexpected URL")
                    enrichments.append(row)
            except (ValueError, KeyError, TypeError) as e:
                self.stages[-1].update(state="invalid_output", error=str(e))
                self.warn("httpx enrichment had invalid records; native HTTP results remain available")
        atomic_json(self.run / "httpx.json", enrichments)
        self.warn("httpx enrichment re-resolves live hostnames and uses its own TLS behavior; native pinned HTTP is the canonical inventory")

    def execute(self):
        if not self.progress["collection"]:
            with self.phase("collection"):
                self.collect()
            self.progress["collection"] = True
            self.checkpoint()
        if self.a.active:
            for round_number in range(self.progress["round"], 1 + max(self.a.feedback_rounds, self.a.recursive_depth)):
                with self.phase("dns_round_" + str(round_number)):
                    self.resolve_round()
                self.checkpoint()
                self.scan_round(round_number)
                # Existing DNS results must also seed HTTP after a stopped DNS/scan phase.
                self.seed_web(list(self.assets.values()))
                self.discovery.seed_content()
                self.checkpoint()
                with self.phase("web_round_" + str(round_number)):
                    self.web_round()
                if self.a.auth_file:
                    with self.phase("auth_round_" + str(round_number)):
                        self.authenticated_round()
                if self.a.browser:
                    with self.phase("browser_round_" + str(round_number)):
                        browser_round(self, STOP)
                with self.phase("infrastructure_" + str(round_number)):
                    self.discovery.infrastructure()
                if round_number < self.a.recursive_depth and self.policy.domain:
                    zones = {a["name"].split(".", 1)[1] for a in self.assets.values()
                             if a["dns"].get("addresses") and not is_ip(a["name"]) and a["name"].count(".") > self.policy.domain.count(".") + 1}
                    self.generate(zones)
                self.progress["round"] = round_number + 1
                self.checkpoint()
            if not self.progress["httpx"]:
                self.httpx()
                self.progress["httpx"] = True
                self.checkpoint()
            if any(a["dns"]["state"] == "not_run" for a in self.assets.values()):
                self.warn("Feedback round limit reached; some newly discovered assets were not resolved")
            if self.assets and not any(a["dns"].get("addresses") for a in self.assets.values()):
                self.warn("No usable addresses observed; review DNS outcomes before interpreting empty web results")
        self.guard()
        if not self.assets:
            self.warn("No accepted assets; review seeds and policy before interpreting an empty run")
        material = [w for w in self.warnings if not w.startswith(("Passive source completeness", "httpx enrichment re-resolves"))]
        self.status = "partial" if material or any(s["state"] != "completed" and not s.get("resumed") for s in self.stages) else "completed"

    def report(self):
        live = [r for r in self.http if r["outcome"] == "response"]
        groups = collections.defaultdict(list)
        for r in live:
            key = str(r["status_code"]) + ":" + r["body_sha256"] + ":" + r["body_hash_scope"]
            groups[key].append({"url": r["url"], "ip": r["ip"]})
        settings = vars(self.a).copy()
        settings["provider_config"] = "configured (not copied)" if self.a.provider_config else None
        result = {"schema": SCHEMA, "version": VERSION, "run_id": self.run.name, "started_at": self.start,
                  "finished_at": utc(), "status": self.status, "error": self.error, "settings": settings,
                  "resume_count": self.resume_count, "checkpoint_semantics": "at_least_once; committed HTTP observations are not repeated",
                  "counts_semantics": "Committed observations plus current session; uncommitted network traffic before a crash may be replayed and is not an exact wire-traffic total",
                  "policy": {"domain_rules": self.policy.allow, "excluded_names": self.policy.denied,
                             "excluded_ips": list(map(str, self.policy.denied_ips)), "allowed_ips": list(map(str, self.policy.ip_allow)),
                             "allow_private": self.policy.private},
                  "tool_versions": self.tools, "input_sha256": self.input_hashes, "stages": self.stages,
                  "warnings": self.warnings, "assets": sorted(self.assets.values(), key=lambda a: a["name"]),
                  "ips": sorted(self.ips.values(), key=lambda a: a["ip"]), "http": self.http,
                  "urls": sorted(self.urls.values(), key=lambda a: a["url"]), "wildcards": self.wildcards,
                  "response_clusters": [{"fingerprint": k, "members": v} for k, v in groups.items() if len(v) > 1],
                  "rejections": self.rejections,
                  "counts": {"assets": len(self.assets), "ips": len(self.ips), "urls": len(self.urls), "http_requests": self.http_count,
                             "http_responses": len(live), "dns_wire_queries": self.dns.count if self.dns else 0},
                  "coverage": {"udp_scanning": "not_implemented", "browser_js_execution": "enabled" if self.a.browser else "not_run", "authentication": "enabled" if self.a.auth_file else "not_run",
                               "dnssec_validation": "recursive_resolver_dependent", "ipv6": "attempted_when_observed" if self.a.active else "not_run",
                               "port_scan": "enabled" if self.a.port_scan else "not_run", "crawl": "enabled" if self.a.crawl else "not_run",
                               "httpx": "enabled" if self.a.httpx_enrich else "not_run", "passive_provider_health": "not_proven",
                               "unresolved_assets": sum(not a["dns"].get("addresses") for a in self.assets.values()),
                               "assets_dns_not_run": sum(a["dns"]["state"] == "not_run" for a in self.assets.values()),
                               "unvisited_urls": sum(a["state"] != "live" for a in self.urls.values())}}
        result["jobs"] = self.store.job_summary()
        result["counts"]["authenticated_http_requests"] = len(self.discovery.state["authenticated"])
        result["counts"]["authenticated_http_responses"] = sum(r["outcome"] == "response" for r in self.discovery.state["authenticated"])
        result["counts"]["browser_requests"] = self.discovery.state.get("browser_request_count", 0)
        result = self.discovery.decorate(result)
        if self.a.baseline:
            old = json.loads(Path(self.a.baseline).read_text(encoding="utf-8"))
            result["delta"] = delta(old, result)
            result["delta"]["comparison_quality"] = comparison_quality(old, result)
            atomic_json(self.run / "delta.json", result["delta"])
        for name, content in (("assets.jsonl", result["assets"]), ("dns.jsonl", [{"name": a["name"], **a["dns"]} for a in result["assets"]]),
                              ("ips.jsonl", result["ips"]), ("live.jsonl", live), ("http.jsonl", self.http), ("urls.jsonl", result["urls"])):
            with (self.run / name).open("w", encoding="utf-8", newline="\n") as f:
                for row in content:
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
        texts = {"candidates.txt": self.assets, "passive_subdomains.txt": [a["name"] for a in self.assets.values() if any(s.startswith(("subfinder:", "passive_import")) for s in a["sources"])],
                 "resolved_subdomains.txt": [a["name"] for a in self.assets.values() if a["kind"] == "hostname" and a["dns"].get("addresses")],
                 "live_urls.txt": {r["url"] for r in live}, "live_hosts.txt": {urllib.parse.urlsplit(r["url"]).hostname for r in live},
                 "ips.txt": self.ips, "urls.txt": self.urls}
        for name, values in texts.items():
            values = sorted(set(values))
            (self.run / name).write_text("\n".join(values) + ("\n" if values else ""), encoding="utf-8")
        for name, key in (("api.json", "api_operations"), ("browser.json", "browser"), ("authenticated.json", "authenticated_http"), ("infrastructure.json", "infrastructure"), ("auth-comparison.json", "auth_comparison")):
            atomic_json(self.run / name, result[key])
        atomic_json(self.run / "report.json", result)
        atomic_json(self.run / "graph.json", inventory_graph(result))
        atomic_json(self.run / "summary.json", {k: result[k] for k in ("schema", "version", "run_id", "status", "error", "counts", "coverage", "warnings", "stages")})
        self.close()
        return result


def inventory_graph(report):
    """Stable typed identifiers, linked only by observed evidence."""
    nodes, edges = {}, {}

    def node(kind, value):
        key = kind + ":" + digest(value.encode("utf-8"))
        nodes[key] = {"id": key, "type": kind, "value": value}
        return key

    def edge(source, target, kind, evidence):
        key = (source, target, kind)
        row = edges.setdefault(key, {"source": source, "target": target, "type": kind, "evidence": []})
        if evidence not in row["evidence"]:
            row["evidence"].append(evidence)

    for asset in report["assets"]:
        source = node(asset["kind"], asset["name"])
        for ip in asset["dns"].get("addresses", []):
            edge(source, node("ip", ip), "resolves_to", "assets:" + asset["name"])
        records = [record for observation in asset["dns"].get("observations", []) for attempt in observation["attempts"] for record in attempt["answers"]]
        for record in records:
            if record.get("type") == "CNAME" and record.get("owner") and record.get("value"):
                edge(node("hostname", record["owner"].rstrip(".")), node("hostname", record["value"].rstrip(".")), "alias_of", "dns:" + asset["name"])
    for ip in report["ips"]:
        source = node("ip", ip["ip"])
        for port in ip["scan"].get("ports", []):
            if port["state"].get("state") == "open":
                target = node("socket", "%s|%s|%d" % (ip["ip"], port["protocol"], port["port"]))
                edge(source, target, "open_port", "ips:" + ip["ip"])
    for url in report["urls"]:
        target = node("url", url["url"])
        edge(node("ip" if is_ip(url["host"]) else "hostname", url["host"]), target, "url_host", "urls:" + url["url"])
        for source in url["sources"]:
            kind, _, parent = source.partition(":")
            if kind in ("html", "js_hint", "form", "robots", "sitemap", "known_file") and parent.startswith(("http://", "https://")):
                edge(node("url", parent), target, "discovered_" + kind, "urls:" + url["url"])
    for index, observation in enumerate(report["http"]):
        if observation["outcome"] != "response":
            continue
        source = node("url", observation["url"])
        target = node("socket", "%s|tcp|%d" % (observation["ip"], observation["port"]))
        edge(source, target, "responded_at", "http:" + str(index))
        redirect = observation.get("redirect", {}).get("url")
        if redirect:
            edge(source, node("url", redirect), "redirects_to", "http:" + str(index))
    return {"schema": "recon-graph/1", "run_id": report["run_id"],
            "nodes": sorted(nodes.values(), key=lambda row: row["id"]),
            "edges": [edges[key] for key in sorted(edges)]}


def delta(old, new):
    if old.get("schema") != SCHEMA:
        raise ValueError("Baseline must use schema " + SCHEMA)
    before = {a["name"]: a for a in old["assets"]}
    after = {a["name"]: a for a in new["assets"]}
    changes = []
    for name in sorted(before.keys() & after.keys()):
        a, b = before[name]["dns"], after[name]["dns"]
        if (a.get("state"), a.get("addresses"), a.get("cnames")) != (b.get("state"), b.get("addresses"), b.get("cnames")):
            changes.append({"name": name, "before": {k: a.get(k) for k in ("state", "addresses", "cnames")},
                            "after": {k: b.get(k) for k in ("state", "addresses", "cnames")}})
    def open_ports(report):
        return {"%s|%s|%d" % (a["ip"], p["protocol"], p["port"]) for a in report["ips"] for p in a["scan"].get("ports", []) if p["state"].get("state") == "open"}
    def web(report):
        return {r["url"] + "|" + r["ip"]: r["status_code"] for r in report["http"] if r["outcome"] == "response"}
    old_web, new_web = web(old), web(new)
    return {"baseline_run": old.get("run_id"), "caution": "Not observed does not mean removed or closed; compare scope, settings and completion first.",
            "policy_matches": old.get("policy") == new.get("policy"), "baseline_status": old.get("status"),
            "new_assets": sorted(after.keys() - before.keys()), "not_observed_assets": sorted(before.keys() - after.keys()),
            "dns_changes": changes, "new_open_ports": sorted(open_ports(new) - open_ports(old)),
            "not_observed_open_ports": sorted(open_ports(old) - open_ports(new)),
            "new_web": sorted(new_web.keys() - old_web.keys()), "not_observed_web": sorted(old_web.keys() - new_web.keys()),
            "http_status_changes": [{"endpoint": k, "before": old_web[k], "after": new_web[k]} for k in sorted(old_web.keys() & new_web.keys()) if old_web[k] != new_web[k]]}


def preflight(a):
    if a.cdn and not a.network_db:
        a.network_db = str(Path(__file__).with_name("data") / "cdn-ranges.json")
    policy = Policy(a)
    AuthProfiles(a.auth_file)
    if not a.active and any((a.browser, a.auth_file, a.openapi, a.asn, a.content_wordlist)):
        raise ValueError("Browser/auth/API/content/ASN features require --active")
    for filename in a.content_wordlist:
        for _, value in lines(filename):
            if "://" in value or ".." in value.split("/") or any(ord(c) <= 32 for c in value):
                raise ValueError("Content wordlist must contain relative URL paths without whitespace or traversal")
    if a.browser:
        try:
            import playwright.sync_api  # noqa: F401
        except ImportError as e:
            raise ValueError("Install requirements-browser.txt and Playwright Chromium first") from e
        if a.browser_executable and not Path(a.browser_executable).is_file():
            raise ValueError("Browser executable does not exist")
    if not a.authorized and not a.check:
        raise ValueError("Use --authorized to confirm authorization")
    if not a.domain and not a.targets and not a.scope:
        raise ValueError("Provide a domain, --scope, or --targets")
    if not a.active and any((a.port_scan, a.service_detection, a.crawl, a.httpx_enrich, a.probe_archives)):
        raise ValueError("Port/service/HTTP/crawl options require --active")
    if a.service_detection and not a.port_scan:
        raise ValueError("--service-detection requires --port-scan")
    if a.probe_all_open and not a.port_scan:
        raise ValueError("--probe-all-open requires --port-scan")
    if a.archive and not a.domain:
        raise ValueError("--archive requires a root domain")
    if a.wordlist and not a.domain:
        raise ValueError("--wordlist requires a root domain")
    if a.top_ports > 65535 or a.threads > 256:
        raise ValueError("--top-ports must be <=65535; --threads must be <=256")
    if a.baseline:
        baseline = json.loads(Path(a.baseline).read_text(encoding="utf-8"))
        if baseline.get("schema") != SCHEMA or not all(k in baseline for k in ("assets", "ips", "http")):
            raise ValueError("Invalid baseline report/schema")
    if a.provider_config and not Path(a.provider_config).is_file():
        raise ValueError("Provider config not found")
    seeds = []
    for name in policy.allow:
        if not name.startswith("*.") and not is_ip(name):
            seeds.append((name, "exact_scope", False))
    for key, source in (("targets", "explicit"), ("passive_file", "passive_import"), ("url_file", "archive_import")):
        for filename in getattr(a, key):
            for number, value in lines(filename):
                try:
                    if value.startswith("{") and key == "passive_file":
                        value = json.loads(value)["host"]
                    if value.startswith(("http://", "https://")):
                        value = url_normalize(value)
                        name = urllib.parse.urlsplit(value).hostname
                        if is_ip(name) and key == "targets":
                            policy.explicit_ips.add(name)
                        seeds.append((value, source, True))
                    elif "/" in value and key == "targets":
                        network = ipaddress.ip_network(value, strict=False)
                        if network.num_addresses > a.max_ips:
                            raise ValueError("CIDR expansion exceeds --max-ips")
                        for ip in network.hosts():
                            policy.explicit_ips.add(str(ip))
                            seeds.append((str(ip), source, False))
                    else:
                        name = host(value)
                        if is_ip(name) and key == "targets":
                            policy.explicit_ips.add(name)
                        seeds.append((name, source, False))
                except (ValueError, KeyError, TypeError) as e:
                    raise ValueError("%s:%d: %s" % (filename, number, e)) from e
    if len(policy.explicit_ips) > a.max_ips:
        raise ValueError("Explicit IP seeds exceed --max-ips")
    # Explicit host/URL seeds extend the default scope, but not a supplied scope file.
    if not a.scope:
        for value, source, is_url in seeds:
            if source == "explicit":
                name = urllib.parse.urlsplit(value).hostname if is_url else value
                if not is_ip(name) and name not in policy.allow:
                    policy.allow.append(name)
    words = []
    seen_words = set()
    for filename in a.wordlist:
        for number, word in lines(filename):
            if not word.isascii() or not all(re.fullmatch(r"[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?", p) for p in word.split(".")):
                raise ValueError("%s:%d: invalid relative DNS prefix" % (filename, number))
            word = word.lower()
            if word not in seen_words:
                words.append(word)
                seen_words.add(word)
    if a.active:
        try:
            import dns
            import dns.query
            import cryptography
        except ImportError as e:
            raise ValueError("Install requirements.txt in a Python virtual environment first (DNS/TLS dependency missing)") from e
        DNS.servers(a.resolvers)
        if a.trusted_resolvers:
            DNS.servers(a.trusted_resolvers)
    requirements = {}
    if a.domain and not a.skip_passive and not a.passive_file:
        requirements["subfinder"] = ["-oJ", "-cs", "-duc", "-config", "-rl", "-max-time"]
    if a.port_scan:
        requirements["nmap"] = ["-Pn", "-sV", "-oX"]
    if a.archive:
        requirements["gau"] = ["--subs", "--threads", "--timeout", "--config"]
    if a.httpx_enrich:
        requirements["httpx"] = ["-nfs", "-tls-grab", "-td", "-allow", "-rstr", "-config", "-pa", "-no-stdin", "-duc"]
    tool_info = {"python": {"version": sys.version.split()[0]}, "dnspython": {"version": dns.__version__} if a.active else {"version": "not_loaded"},
                 "cryptography": {"version": cryptography.__version__} if a.active else {"version": "not_loaded"}}
    for name, flags in requirements.items():
        path = shutil.which(getattr(a, name + "_bin"))
        if not path:
            raise ValueError("Required executable not found: " + name)
        path = str(Path(path).resolve())
        try:
            result = subprocess.run([path, "--help" if name == "gau" else "-h"], capture_output=True, text=True, errors="replace", timeout=20,
                                    stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            help_text = result.stdout + result.stderr
            missing = [flag for flag in flags if not re.search(r"(?<![\w-])" + re.escape(flag) + r"(?![\w-])", help_text)]
            if missing:
                raise ValueError(name + " interface mismatch; missing " + ", ".join(missing))
            result = subprocess.run([path, "--version" if name in ("nmap", "gau") else "-version"], capture_output=True, text=True, errors="replace", timeout=20,
                                    stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            if result.returncode != 0:
                raise ValueError(name + " version check failed: " + (result.stdout + result.stderr).strip()[:1000])
            tool_info[name] = {"path": path, "version": (result.stdout + result.stderr).strip()[:2000], "binary_sha256": digest(Path(path).read_bytes())}
        except (OSError, subprocess.TimeoutExpired) as e:
            raise ValueError("Tool preflight failed: " + name + ": " + str(e)) from e
    return policy, seeds, words, tool_info


def main(argv=None):
    os.umask(0o077)
    STOP.clear()
    a = parser().parse_args(argv)
    try:
        if a.resume:
            actual = list(sys.argv[1:] if argv is None else argv)
            allowed = {"--resume", "--authorized", "--run-timeout", "--max-http", "--max-dns-queries"}
            i = 0
            while i < len(actual):
                flag = actual[i].split("=", 1)[0]
                if flag not in allowed:
                    raise ValueError("--resume only accepts --authorized, --run-timeout and increased --max-http/--max-dns-queries")
                i += 1 if "=" in actual[i] or flag == "--authorized" else 2
            if not a.authorized:
                raise ValueError("Resume requires --authorized")
            saved = read_saved(a.resume)
            if saved.get("version") != VERSION:
                raise ValueError("Resume requires the same application version")
            run = Path(a.resume).resolve()
            for filename, expected in saved["input_hashes"].items():
                if digest((run / "inputs" / filename).read_bytes()) != expected:
                    raise ValueError("Checkpoint input changed: " + filename)
            for filename in (name for name in saved["input_hashes"] if name.endswith(".py")):
                if digest(Path(__file__).with_name(filename).read_bytes()) != saved["input_hashes"][filename]:
                    raise ValueError("Application code changed; start a new run")
            overrides = {}
            for key in ("run_timeout", "max_http", "max_dns_queries"):
                if any(v.split("=", 1)[0] == "--" + key.replace("_", "-") for v in actual):
                    value = getattr(a, key)
                    if key != "run_timeout" and value < saved["settings"][key]:
                        raise ValueError("Resume budgets may only increase")
                    overrides[key] = value
            a = argparse.Namespace(**saved["settings"])
            a.resume, a.authorized = str(run), True
            for key, value in overrides.items():
                setattr(a, key, value)
            if a.auth_file and digest(Path(a.auth_file).read_bytes()) != saved["auth_sha256"]:
                raise ValueError("Authentication profile changed; start a new run")
        policy, seeds, words, tool_info = preflight(a)
        if a.resume and tool_info != saved["tools"]:
            raise ValueError("Tool versions or binaries changed; start a new run")
    except (ValueError, OSError) as e:
        print("ERROR: " + str(e), file=sys.stderr)
        return 2
    if a.check:
        print(json.dumps({"status": "check_passed", "version": VERSION, "seeds": len(seeds), "wordlist_entries": len(words), "tools": tool_info}, indent=2))
        return 0
    caught_signal = [None]
    def interrupted(signum, _frame):
        caught_signal[0] = signum
        STOP.set()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    p = None
    code = 1
    try:
        p = Pipeline(a, policy, seeds, words, tool_info)
        p.execute()
        code = 0 if p.status == "completed" else 1
    except Interrupted:
        code = 128 + (caught_signal[0] or signal.SIGINT)
        if p:
            p.status, p.error = "interrupted", "Interrupted by signal"
    except BudgetExceeded as e:
        code = 124 if str(e) == "Overall run timeout" else 1
        if p:
            p.status, p.error = "timed_out" if code == 124 else "partial", str(e)
    except Exception as e:
        if p:
            p.status, p.error = "failed", type(e).__name__ + ": " + str(e)
        else:
            print("ERROR: " + str(e), file=sys.stderr)
    finally:
        if p:
            try:
                result = p.report()
                print(json.dumps({"status": result["status"], "report": str(p.run / "report.json"), "counts": result["counts"]}))
            except Exception as e:
                print("ERROR writing report: " + str(e) + "; incremental events retained in " + str(p.run), file=sys.stderr)
                code = 1
            finally:
                p.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
