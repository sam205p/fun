"""Terminal heartbeat; percentages describe a changing plan, never scan coverage."""
import json
import os
import shutil
import sys
import threading
import time
from pathlib import Path


class StatusDisplay:
    def __init__(self, pipeline, stream=None):
        self.pipeline = pipeline
        self.stream = stream if stream is not None else sys.stderr
        mode = getattr(pipeline.a, "status", "auto")
        self.enabled = mode != "off"
        self.terminal = mode == "bar" or (mode == "auto" and self.stream.isatty())
        self.stop = threading.Event()
        self.thread = None
        self.output_lock = threading.Lock()
        self.last_line = None
        self.last_print = 0.0

    def start(self):
        self.emit()
        self.thread = threading.Thread(target=self._run, name="recon-status", daemon=True)
        self.thread.start()

    def _run(self):
        while not self.stop.wait(1):
            self.emit()

    def emit(self, final=False):
        state = self.pipeline.status_snapshot()
        path = Path(self.pipeline.run) / "status.json"
        temp = path.with_suffix(".json.tmp")
        try:
            temp.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
            os.replace(temp, path)
        except OSError:
            # Display failure must not discard the durable scan checkpoint.
            pass
        if not self.enabled:
            return
        pct = state["plan_percent_estimate"]
        filled = int(pct / 5)
        work = state["stage_work"]
        detail = f" | {work['done']}/{work['total']} {work['unit']}" if work else ""
        line = (f"[{'#' * filled}{'-' * (20 - filled)}] plan ~{pct:.1f}% | "
                f"{state['status']} | {state['stage']}{detail} | "
                f"HTTP {state['http_requests']}/{state['http_budget']} | "
                f"elapsed {state['session_elapsed_seconds']}s | {state['activity']}")
        # Target-controlled titles/URLs cannot inject terminal control sequences.
        line = "".join(c if c.isprintable() else " " for c in line)
        if self.terminal:
            line = line[:max(20, shutil.get_terminal_size((120, 24)).columns - 1)]
        now = time.monotonic()
        with self.output_lock:
            if self.terminal:
                self.stream.write("\r\033[2K" + line + ("\n" if final else ""))
            elif final or state["stage"] != self.last_line or now - self.last_print >= 10:
                self.stream.write(line + "\n")
            else:
                return
            self.stream.flush()
        self.last_line, self.last_print = state["stage"], now

    def message(self, message):
        with self.output_lock:
            if self.enabled and self.terminal:
                self.stream.write("\r\033[2K")
            self.stream.write(message + "\n")
            self.stream.flush()

    def close(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=2)
        self.emit(final=True)
