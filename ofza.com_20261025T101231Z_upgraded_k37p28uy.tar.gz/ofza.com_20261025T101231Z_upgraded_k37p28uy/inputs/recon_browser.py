"""Optional Playwright adapter. Inventory browser activity without form submission."""
import json
import os
import signal
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path

from recon_discovery import origin


def check_browser(executable=None):
    """Probe the installed driver and render locally in a bounded child process."""
    code = """
import sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path=sys.argv[1] or None, timeout=10000)
    try:
        page = browser.new_page()
        page.set_content('<title>recon-preflight</title>', timeout=5000)
        assert page.title() == 'recon-preflight'
    finally:
        browser.close()
"""
    proc = None
    try:
        proc = subprocess.Popen([sys.executable, "-c", code, executable or ""],
                                cwd=str(Path(__file__).parent), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, errors="replace",
                                start_new_session=os.name != "nt")
        stdout, stderr = proc.communicate(timeout=25)
    except (OSError, subprocess.TimeoutExpired) as exc:
        if proc is not None:
            try:
                if os.name != "nt":
                    os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                proc.communicate(timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                pass
        raise ValueError("Browser preflight failed: " + str(exc)) from exc
    if proc.returncode:
        details = (stderr + stdout).strip()
        raise ValueError("Browser preflight failed with " + sys.executable + ": " + details[-2500:] +
                         ". Use the project .venv and install requirements-browser.txt and Playwright Chromium.")


def browser_round(pipeline, stop):
    from playwright.sync_api import sync_playwright, Error

    p = pipeline
    state = p.discovery.state
    state.setdefault("browser_request_count", 0)
    candidates = []
    seen = set()
    for row in p.http + state["authenticated"]:
        url = row["url"]
        if row["outcome"] != "response" or "html" not in row.get("content_type", ""):
            continue
        for context_name in (["anonymous", "authenticated"] if origin(url) in p.discovery.auth.profiles else ["anonymous"]):
            key = context_name + "|" + url
            if key not in state["browser_done"] and key not in seen:
                seen.add(key)
                candidates.append((url, context_name, key))
    remaining = p.a.browser_pages - len(state["browser_done"])
    if remaining <= 0:
        if candidates:
            p.warn("Browser page budget reached; rendered coverage is incomplete")
            p.mark_phase_incomplete("Browser page budget reached")
        return
    if not candidates:
        return
    p.set_stage_work(0, min(len(candidates), remaining), "browser pages")
    mappings = []
    for name, asset in p.assets.items():
        addresses = [ip for ip in asset["dns"].get("addresses", []) if p.policy.ip(ip)]
        if addresses and asset["kind"] == "hostname":
            address = "[" + addresses[0] + "]" if ":" in addresses[0] else addresses[0]
            mappings.append("MAP %s %s" % (name, address))
    with sync_playwright() as engine:
        browser = engine.chromium.launch(headless=True, executable_path=p.a.browser_executable,
            args=["--no-proxy-server", "--disable-background-networking", "--disable-quic", "--disable-features=Prerender2",
                  "--host-resolver-rules=" + ",".join(mappings + ["MAP * ~NOTFOUND"])])
        try:
            for url, context_name, key in candidates[:remaining]:
                p.guard()
                p.activity = "Rendering " + url
                record = {"url": url, "context": context_name, "state": "running", "requests": [], "websockets": [], "dom_links": []}
                profile = p.discovery.auth.profiles.get(origin(url), {}) if context_name == "authenticated" else {}
                context = browser.new_context(ignore_https_errors=not p.a.tls_verify, service_workers="block", accept_downloads=False)
                try:
                    # Restrict an authenticated browser context to its origin. Other
                    # discovered origins still enter the native pipeline separately.
                    cookie_header = next((v for k, v in profile.get("headers", {}).items() if k.lower() == "cookie"), "")
                    for part in cookie_header.split(";"):
                        if "=" in part:
                            name, value = part.strip().split("=", 1)
                            context.add_cookies([{"name": name, "value": value, "url": origin(url)}])
                    if profile.get("local_storage"):
                        page_origin = origin(url)
                        default = ":443" if url.startswith("https:") else ":80"
                        if page_origin.endswith(default):
                            page_origin = page_origin[:-len(default)]
                        context.add_init_script("if (location.origin === " + json.dumps(page_origin) + ") { for (const [k,v] of Object.entries(" + json.dumps(profile["local_storage"]) + ")) localStorage.setItem(k,v); }")

                    def route_request(route):
                        request = route.request
                        target = request.url
                        parsed = urllib.parse.urlsplit(target)
                        row = {"url": target, "method": request.method, "resource_type": request.resource_type, "state": "observed"}
                        # Bound reporting even if hostile JS spins an infinite request loop.
                        if len(record["requests"]) < p.a.browser_requests:
                            record["requests"].append(row)
                        allowed = parsed.scheme in ("http", "https") and parsed.hostname and p.policy.name(parsed.hostname)
                        asset = p.assets.get(parsed.hostname, {})
                        allowed = allowed and any(p.policy.ip(ip) for ip in asset.get("dns", {}).get("addresses", []))
                        if parsed.scheme in ("http", "https"):
                            p.add_url(target, "browser:" + url, method=request.method, probe=request.method == "GET", depth=p.urls[url]["depth"] + 1)
                        if context_name == "authenticated" and (not allowed or origin(target) != origin(url)):
                            allowed = False
                        if stop.is_set() or time.monotonic() >= p.deadline or state["browser_request_count"] >= p.a.browser_requests or not allowed or request.method not in ("GET", "HEAD") or request.resource_type in ("image", "media", "font"):
                            row["state"] = "not_sent"
                            route.abort()
                            return
                        while p.pacer.ready_in(origin(target)) and not stop.is_set() and time.monotonic() < p.deadline:
                            stop.wait(min(0.1, p.pacer.ready_in(origin(target))))
                        if stop.is_set() or time.monotonic() >= p.deadline:
                            row["state"] = "not_sent"
                            route.abort()
                            return
                        p.http_limiter.wait()
                        if stop.is_set() or time.monotonic() >= p.deadline:
                            row["state"] = "not_sent"
                            route.abort()
                            return
                        state["browser_request_count"] += 1
                        headers = request.all_headers()
                        if context_name == "authenticated":
                            headers.update({k: v for k, v in p.discovery.auth.headers(target).items() if k.lower() != "cookie"})
                        route.continue_(headers=headers)
                        row["state"] = "sent"

                    def response_seen(response):
                        for row in reversed(record["requests"]):
                            if row["url"] == response.url and "status" not in row:
                                row["status"] = response.status
                                break
                        p.pacer.observe(origin(response.url), {"outcome": "response", "status_code": response.status, "headers": response.headers})

                    def websocket_seen(socket):
                        if len(record["websockets"]) < p.a.browser_requests:
                            record["websockets"].append({"url": socket.url, "state": "endpoint_observed_connection_not_opened"})
                        # Do not connect_to_server: this is a mocked socket. Closing
                        # synchronously inside the route callback can deadlock before
                        # the opening handshake completes; context.close owns cleanup.

                    context.route("**/*", route_request)
                    context.route_web_socket("**/*", websocket_seen)
                    page = context.new_page()
                    page.on("response", response_seen)
                    page.on("dialog", lambda dialog: dialog.dismiss())
                    try:
                        page.goto(url, wait_until="domcontentloaded", timeout=max(1, min(p.a.request_timeout, p.deadline - time.monotonic()) * 1000))
                        until = min(time.monotonic() + p.a.browser_wait, p.deadline)
                        while time.monotonic() < until and not stop.is_set():
                            page.wait_for_timeout(min(100, max(1, (until - time.monotonic()) * 1000)))
                        links = page.locator("a[href],iframe[src],script[src]").evaluate_all("els => els.map(e => e.href || e.src)")
                        record["dom_links"] = links[:p.a.max_urls]
                        for link in record["dom_links"]:
                            p.add_url(link, "browser_dom:" + url, depth=p.urls[url]["depth"] + 1,
                                      probe=p.urls[url]["depth"] < p.a.crawl_depth)
                        record["state"] = "completed"
                    except Error as exc:
                        record["state"], record["error"] = "page_error", str(exc)[:1000]
                        p.warn("Browser page did not complete: " + url)
                finally:
                    context.close()
                if stop.is_set() or time.monotonic() >= p.deadline:
                    p.guard()
                record = p.discovery.auth.redact(record)
                state["browser"].append(record)
                state["browser_done"].append(key)
                p.event("browser_page", record)
                p.set_stage_work(p.stage_work["done"] + 1, p.stage_work["total"], "browser pages")
                p.checkpoint()
            if state["browser_request_count"] >= p.a.browser_requests:
                p.warn("Browser request budget reached; rendered coverage is incomplete")
                p.mark_phase_incomplete("Browser request budget reached")
            if len(candidates) > remaining:
                p.warn("Browser page budget reached; rendered coverage is incomplete")
                p.mark_phase_incomplete("Browser page budget reached")
        finally:
            browser.close()
