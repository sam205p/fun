"""Original recon modules: authentication, API discovery, calibration and evidence."""
import datetime
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import urllib.parse
import uuid


def origin(url):
    parsed = urllib.parse.urlsplit(url)
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    host = ("[" + parsed.hostname + "]") if ":" in parsed.hostname else parsed.hostname
    return "%s://%s:%d" % (parsed.scheme, host, port)


def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class AuthProfiles:
    """Headers are kept in memory; never copy credential files into a run."""
    def __init__(self, path=None):
        self.profiles = {}
        if not path:
            return
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
        for url, entry in data.get("origins", {}).items():
            parsed = urllib.parse.urlsplit(url)
            if parsed.scheme not in ("https", "http") or not parsed.hostname or parsed.username or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
                raise ValueError("Auth keys must be exact HTTP(S) origins")
            headers = entry.get("headers", {})
            for name, value in headers.items():
                if not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name) or not isinstance(value, str) or any(ord(c) < 32 or ord(c) > 126 for c in value):
                    raise ValueError("Invalid auth header")
                if name.lower() in ("host", "connection", "content-length", "transfer-encoding", "accept-encoding"):
                    raise ValueError("Reserved transport header in auth profile")
            local = entry.get("local_storage", {})
            if not isinstance(local, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in local.items()):
                raise ValueError("local_storage must map strings to strings")
            self.profiles[origin(url)] = {"headers": headers, "local_storage": local}

    def headers(self, url):
        return dict(self.profiles.get(origin(url), {}).get("headers", {}))

    def redact(self, value):
        secrets = []
        for entry in self.profiles.values():
            secrets.extend(entry["headers"].values())
            secrets.extend(entry["local_storage"].values())
            for name, content in entry["headers"].items():
                if name.lower() == "cookie":
                    secrets.extend(part.split("=", 1)[1].strip() for part in content.split(";") if "=" in part)
                elif name.lower() == "authorization":
                    secrets.append(content.split(" ", 1)[-1])
        def clean(item):
            if isinstance(item, str):
                for secret in secrets:
                    if len(secret) >= 4:
                        item = item.replace(secret, "[REDACTED]")
                return item
            if isinstance(item, list):
                return [clean(v) for v in item]
            if isinstance(item, dict):
                return {k: clean(v) for k, v in item.items()}
            return item
        return clean(value)


def api_operations(document, base):
    """OpenAPI 3.x / Swagger 2 JSON inventory, no external $ref fetching."""
    if not isinstance(document, dict) or not (str(document.get("openapi", "")).startswith("3.") or document.get("swagger") == "2.0"):
        return []
    if document.get("swagger") == "2.0":
        parsed = urllib.parse.urlsplit(base)
        root = (document.get("schemes") or [parsed.scheme])[0] + "://" + document.get("host", parsed.netloc) + document.get("basePath", "")
        servers = [{"url": root}]
    else:
        servers = document.get("servers") or [{"url": "/"}]
    result = []
    paths = document.get("paths", {})
    if not isinstance(paths, dict):
        return []
    for path, item in paths.items():
        if not isinstance(item, dict) or not path.startswith("/"):
            continue
        for method, operation in item.items():
            if method.lower() not in ("get", "head", "post", "put", "delete", "patch", "options", "trace") or not isinstance(operation, dict):
                continue
            selected = operation.get("servers") or item.get("servers") or servers
            for server in selected[:20]:
                if not isinstance(server, dict) or not isinstance(server.get("url"), str):
                    continue
                root = server["url"]
                for name, spec in server.get("variables", {}).items():
                    if isinstance(spec, dict) and "default" in spec:
                        root = root.replace("{" + name + "}", str(spec["default"]))
                resolved = urllib.parse.urljoin(base, root).rstrip("/") + path
                result.append({"url": resolved, "method": method.upper(), "templated": "{" in resolved,
                               "operation_id": operation.get("operationId"), "source": base,
                               "parameters": [p.get("name") for p in item.get("parameters", []) + operation.get("parameters", []) if isinstance(p, dict) and p.get("name")]})
                if len(result) >= 10000:
                    return result
    return result


def js_endpoints(body):
    # Static hints, not JavaScript evaluation. Relative fetch/import URLs are retained.
    expressions = [r'''(?:fetch|WebSocket|EventSource|import)\s*\(\s*["'`]([^"'`\s<>]{1,2048})["'`]''',
                   r'''axios\.(?:get|post|put|patch|delete)\s*\(\s*["']([^"'\s<>]{1,2048})["']''',
                   r'''\.open\s*\(\s*["'](?:GET|HEAD|POST|PUT|PATCH|DELETE)["']\s*,\s*["']([^"'\s<>]{1,2048})["']''']
    return sorted({match for expression in expressions for match in re.findall(expression, body) if "${" not in match})


def fingerprint(response, body):
    path = urllib.parse.urlsplit(response["url"]).path
    normalized = body.replace(response["url"], "<requested-url>").replace(path, "<requested-path>")
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return "%s:%s" % (response.get("status_code"), hashlib.sha256(normalized.encode()).hexdigest())


class Discovery:
    def __init__(self, pipeline):
        self.p = pipeline
        self.auth = AuthProfiles(pipeline.a.auth_file)
        self.state = {"content_origins": [], "controls": {}, "fingerprints": {}, "api": [], "browser": [], "browser_done": [],
                      "authenticated": [], "auth_done": [], "infra": {}, "provider_failures": []}
        self.paths = []
        for filename in pipeline.a.content_wordlist:
            for line in Path(filename).read_text(encoding="utf-8-sig").splitlines():
                value = line.strip()
                if value and not value.startswith("#"):
                    self.paths.append(value)
        self.paths = list(dict.fromkeys(self.paths))
        self.networks = []
        if pipeline.a.network_db:
            data = json.loads(Path(pipeline.a.network_db).read_text(encoding="utf-8-sig"))
            # Supports cdncheck's public sources_data.json without vendoring its database.
            for kind in ("cdn", "cloud", "waf"):
                for provider, ranges in data.get(kind, {}).items():
                    for cidr in ranges:
                        self.networks.append((ipaddress.ip_network(cidr), {"kind": kind, "provider": provider, "source": "network_db", "prefix": cidr}))
            for row in data.get("networks", []):
                self.networks.append((ipaddress.ip_network(row["cidr"]), {**row, "source": "network_db"}))

    def seed_content(self):
        if not self.paths and not self.p.a.openapi:
            return
        for asset in list(self.p.urls.values()):
            root = origin(asset["url"])
            if root in self.state["content_origins"]:
                continue
            self.state["content_origins"].append(root)
            if self.paths:
                controls = [root + "/rp-missing-" + uuid.uuid4().hex for _ in range(2)]
                self.state["controls"][root] = controls
                for url in controls:
                    self.p.add_url(url, "soft404_control")
                for path in self.paths:
                    if len(self.p.urls) >= self.p.a.max_urls:
                        break
                    self.p.add_url(root + "/" + path.lstrip("/"), "content_wordlist")
            if self.p.a.openapi:
                for path in ("/openapi.json", "/swagger.json", "/v3/api-docs"):
                    self.p.add_url(root + path, "openapi_probe")

    def observe(self, response, body, context="anonymous"):
        if response.get("outcome") != "response":
            return
        key = response["url"] + "|" + response["ip"] + "|" + context
        if not response.get("body_truncated"):
            self.state["fingerprints"][key] = fingerprint(response, body)
        if self.p.a.openapi and ("json" in response.get("content_type", "") or body.lstrip().startswith("{")):
            try:
                operations = api_operations(json.loads(body), response["url"])
            except (ValueError, TypeError, AttributeError):
                operations = []
            for operation in operations:
                if len(self.state["api"]) >= self.p.a.max_urls:
                    break
                if operation not in self.state["api"]:
                    self.state["api"].append(operation)
                if not operation["templated"]:
                    self.p.add_url(operation["url"], "openapi:" + response["url"], method=operation["method"], probe=operation["method"] == "GET")
        if self.p.a.crawl and "javascript" in response.get("content_type", ""):
            for url in js_endpoints(body):
                if not url.startswith(("ws:", "wss:")):
                    self.p.add_url(url, "js_parser:" + response["url"], base=response["url"], depth=response.get("depth", 0) + 1,
                                   probe=response.get("depth", 0) < self.p.a.crawl_depth)

    def infrastructure(self):
        for ip, entry in self.p.ips.items():
            address = ipaddress.ip_address(ip)
            evidence = self.state["infra"].setdefault(ip, {"matches": [], "asn": None, "shared_ip": len(entry["names"]) > 1,
                                                         "ownership": "not_inferred", "observed_at": timestamp()})
            evidence["shared_ip"] = len(entry["names"]) > 1
            evidence["matches"] = [row for network, row in self.networks if address.version == network.version and address in network]
            if self.p.a.asn and address.is_global and evidence["asn"] is None:
                if address.version == 4:
                    query = ".".join(reversed(ip.split("."))) + ".origin.asn.cymru.com"
                else:
                    query = ".".join(reversed(address.exploded.replace(":", ""))) + ".origin6.asn.cymru.com"
                observation = self.p.dns.query(query, "TXT")
                rows = []
                for attempt in observation["attempts"]:
                    for rr in attempt["answers"]:
                        if rr["type"] == "TXT":
                            columns = [v.strip(' "') for v in rr["value"].split("|")]
                            if len(columns) >= 5:
                                rows.append({"asn": columns[0], "prefix": columns[1], "country": columns[2], "registry": columns[3], "allocated": columns[4]})
                evidence["asn"] = {"source": "Team Cymru DNS", "outcome": observation["outcome"], "records": rows}

    def decorate(self, result):
        for response in result["http"]:
            root = origin(response["url"])
            context = response.get("context", "anonymous")
            controls = self.state["controls"].get(root, [])
            values = [self.state["fingerprints"].get(url + "|" + response["ip"] + "|" + context) for url in controls]
            candidate = self.state["fingerprints"].get(response["url"] + "|" + response["ip"] + "|" + context)
            response["soft404"] = "control" if response["url"] in controls else "possible" if len(values) >= 2 and all(values) and len(set(values)) == 1 and candidate == values[0] else "not_matched" if len(values) >= 2 and all(values) else "not_calibrated"
        for asset in result["assets"]:
            expirations = []
            for observation in asset["dns"].get("observations", []):
                for attempt in observation["attempts"]:
                    for rr in attempt["answers"]:
                        if isinstance(rr.get("ttl"), int):
                            expirations.append(rr["ttl"])
            when = asset["dns"].get("at")
            expiry = None
            if when and expirations:
                expiry = (datetime.datetime.fromisoformat(when) + datetime.timedelta(seconds=min(expirations))).isoformat()
            sources = asset["sources"]
            asset["evidence_quality"] = {"status": "resolved" if asset["dns"].get("addresses") else "lead",
                                         "source_count": len(sources), "independence": "not_assumed", "dns_expires_at": expiry,
                                         "historical_only": bool(sources) and all("archive" in s for s in sources)}
        result["api_operations"] = self.state["api"]
        result["browser"] = self.state["browser"]
        result["authenticated_http"] = self.state["authenticated"]
        result["infrastructure"] = self.state["infra"]
        anonymous = {(r["url"], r["ip"]): r for r in result["http"]}
        result["auth_comparison"] = [{"url": r["url"], "ip": r["ip"], "anonymous_status": anonymous.get((r["url"], r["ip"]), {}).get("status_code"),
                                      "authenticated_status": r.get("status_code"), "body_changed": anonymous.get((r["url"], r["ip"]), {}).get("body_sha256") != r.get("body_sha256"),
                                      "interpretation": "observation_only_not_access_control_verdict"} for r in self.state["authenticated"]]
        return self.auth.redact(result)


def comparison_quality(old, new):
    ignored = {"output", "resume", "authorized", "check", "baseline", "run_timeout", "provider_config",
               "targets", "passive_file", "url_file", "wordlist", "scope", "exclude", "ip_allow", "resolvers", "trusted_resolvers", "content_wordlist", "network_db"}
    differences = sorted(key for key in old.get("settings", {}).keys() | new.get("settings", {}).keys()
                         if key not in ignored and old.get("settings", {}).get(key) != new.get("settings", {}).get(key))
    reasons = []
    if old.get("policy") != new.get("policy"):
        reasons.append("policy_changed")
    if differences:
        reasons.append("settings_changed")
    if old.get("status") != "completed" or new.get("status") != "completed":
        reasons.append("incomplete_run")
    if old.get("tool_versions") != new.get("tool_versions"):
        reasons.append("tool_versions_changed")
    old_hash = {k: v for k, v in old.get("input_sha256", {}).items() if not k.endswith(".py")}
    new_hash = {k: v for k, v in new.get("input_sha256", {}).items() if not k.endswith(".py")}
    if old_hash != new_hash:
        reasons.append("inputs_changed")
    return {"comparable": not reasons, "reasons": reasons, "changed_settings": differences,
            "absence_interpretation": "not_observed_never_proof_of_removal", "passive_provider_completeness": "not_proven"}
