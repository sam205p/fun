"""Durable checkpoints and bounded, destination-aware HTTP pacing."""
import datetime
import email.utils
import json
import math
import os
from pathlib import Path
import random
import sqlite3
import time
import zlib


class StateStore:
    """Single-writer, transactional snapshots. Network operations are at-least-once."""

    def __init__(self, directory):
        self.lock = (Path(directory) / "run.lock").open("a+b")
        self.db = None
        try:
            self.lock.seek(0)
            if os.name == "nt":
                import msvcrt
                if not self.lock.read(1):
                    self.lock.write(b"0")
                    self.lock.flush()
                self.lock.seek(0)
                msvcrt.locking(self.lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.db = sqlite3.connect(str(Path(directory) / "state.sqlite"))
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA synchronous=FULL")
            self.db.execute("CREATE TABLE IF NOT EXISTS checkpoint (id INTEGER PRIMARY KEY CHECK(id=1), payload BLOB NOT NULL)")
            self.db.execute("CREATE TABLE IF NOT EXISTS entries (bucket TEXT, item TEXT, value BLOB NOT NULL, PRIMARY KEY(bucket,item))")
            self.db.execute("CREATE TABLE IF NOT EXISTS jobs (kind TEXT, key TEXT, state TEXT, attempts INTEGER DEFAULT 0, result BLOB, PRIMARY KEY(kind,key))")
            self.db.commit()
            self.cache = {}
        except Exception:
            self.close()
            raise

    def read(self):
        row = self.db.execute("SELECT payload FROM checkpoint WHERE id=1").fetchone()
        return unpack(self.db, row) if row else None

    def save(self, state):
        metadata = dict(state)
        buckets = {}
        for name in ("assets", "urls", "ips", "wildcards", "http", "stages", "warnings", "rejections"):
            value = metadata.pop(name)
            buckets[name] = ("dict" if isinstance(value, dict) else "list", value)
        metadata["buckets"] = {k: v[0] for k, v in buckets.items()}
        data = pack(metadata)
        changed = {}
        with self.db:
            self.db.execute("INSERT OR REPLACE INTO checkpoint(id,payload) VALUES(1,?)", (data,))
            for name, (kind, items) in buckets.items():
                keys = set()
                for key, value in (items.items() if kind == "dict" else enumerate(items)):
                    key = str(key)
                    keys.add(key)
                    encoded = pack(value)
                    if self.cache.get((name, key)) != encoded:
                        self.db.execute("INSERT OR REPLACE INTO entries VALUES(?,?,?)", (name, key, encoded))
                        changed[(name, key)] = encoded
                existing = {row[0] for row in self.db.execute("SELECT item FROM entries WHERE bucket=?", (name,))}
                for key in existing - keys:
                    self.db.execute("DELETE FROM entries WHERE bucket=? AND item=?", (name, key))
                    changed[(name, key)] = None
        for key, value in changed.items():
            if value is None:
                self.cache.pop(key, None)
            else:
                self.cache[key] = value

    def cached_job(self, kind, key):
        row = self.db.execute("SELECT result FROM jobs WHERE kind=? AND key=? AND state='done'", (kind, key)).fetchone()
        return json.loads(zlib.decompress(row[0])) if row else None

    def start_job(self, kind, key):
        with self.db:
            self.db.execute("INSERT INTO jobs(kind,key,state,attempts) VALUES(?,?,'running',1) ON CONFLICT(kind,key) DO UPDATE SET state='running',attempts=attempts+1", (kind, key))

    def finish_job(self, kind, key, result):
        with self.db:
            self.db.execute("UPDATE jobs SET state='done',result=? WHERE kind=? AND key=?", (pack(result), kind, key))

    def job_summary(self):
        return [{"kind": k, "state": s, "count": n} for k, s, n in self.db.execute("SELECT kind,state,COUNT(*) FROM jobs GROUP BY kind,state")]

    def close(self):
        if self.db is not None:
            self.db.close()
            self.db = None
        if not self.lock.closed:
            self.lock.close()


def read_saved(directory):
    path = Path(directory).resolve() / "state.sqlite"
    if not path.is_file():
        raise ValueError("Resume requires an existing state.sqlite from this release")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    try:
        row = connection.execute("SELECT payload FROM checkpoint WHERE id=1").fetchone()
        if not row:
            raise ValueError("No durable checkpoint available")
        return unpack(connection, row)
    except (sqlite3.Error, zlib.error, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError("Invalid checkpoint: " + str(exc)) from exc
    finally:
        connection.close()


def pack(value):
    return zlib.compress(json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode(), 1)


def unpack(connection, row):
    result = json.loads(zlib.decompress(row[0]))
    for name, kind in result.pop("buckets", {}).items():
        items = {key: json.loads(zlib.decompress(data)) for key, data in connection.execute("SELECT item,value FROM entries WHERE bucket=?", (name,))}
        result[name] = items if kind == "dict" else [items[key] for key in sorted(items, key=int)]
    return result


def retry_after(value, now=None):
    """Return nonnegative seconds for RFC Retry-After delta or HTTP-date."""
    if not value:
        return 0.0
    if value.strip().isdigit():
        # Bound integer parsing for untrusted headers; an enormous value means defer.
        return min(float(value.strip()[:12]), 315360000.0)
    try:
        date = email.utils.parsedate_to_datetime(value)
        if date.tzinfo is None:
            date = date.replace(tzinfo=datetime.timezone.utc)
        return max(0.0, date.timestamp() - (time.time() if now is None else now))
    except (TypeError, ValueError, OverflowError):
        return 0.0


class AdaptivePacer:
    """A global ceiling plus independent origin cooldowns; no hidden retries."""

    def __init__(self, delay=0.0, jitter=0.0, cap=60.0, now=time.time):
        self.delay, self.jitter, self.cap, self.now = delay, jitter, cap, now
        self.origins = {}

    def ready_in(self, origin):
        return max(0.0, self.origins.get(origin, {}).get("until", 0.0) - self.now())

    def observe(self, origin, response):
        row = self.origins.setdefault(origin, {"penalty": 0.0, "until": 0.0})
        status = response.get("status_code")
        if status in (429, 503):
            row["penalty"] = min(self.cap, max(1.0, row["penalty"] * 2))
        elif response.get("outcome") == "response":
            row["penalty"] *= 0.5
        server_delay = retry_after(response.get("headers", {}).get("retry-after")) if status in (429, 503) else 0.0
        wait = max(self.delay, row["penalty"], server_delay) + random.uniform(0.0, self.jitter)
        if not math.isfinite(wait):
            wait = 315360000.0
        row["until"] = self.now() + wait
        return wait
